package com.ufrn.mandala.sosmanager.dao;

import java.util.ArrayList;

import com.ufrn.mandala.model.CSystem;
import com.ufrn.mandala.model.CSystemSos;
import com.ufrn.mandala.model.Pair;
import com.ufrn.mandala.model.StepCs;
import com.ufrn.mandala.model.SystemInformations;
import com.ufrn.mandala.model.Task;
import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ExclusiveGatewayStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;

import com.ufrn.mandala.sosmanager.db.*;

public class SoSManagerDataBaseDAO {
	
	private CS_SoSTable csSoSdao;
	private CSystemTable csystemdao;
	private MissionTable missiondao ;
	private SoSTable sosdao;
	private Step_CSTable stepSystemdao;
	private StepTable stepdao;
	private TaskTable taskdao;
	private TaskSystemTable taskSystemdao;
	private ParameterTable parameterdao;
	
	/**
	 * Construtor dos BD
	 */
	public SoSManagerDataBaseDAO(){
		parameterdao = new ParameterTable();
		parameterdao.droptable();
		parameterdao.setUp();
		
		csystemdao = new CSystemTable();
		csystemdao.droptable();
		csystemdao.setUp();
		
		taskdao = new TaskTable();
		taskdao.droptable();
		taskdao.setUp();
		
		taskSystemdao = new TaskSystemTable();
		taskSystemdao.droptable();
		taskSystemdao.setUp();
		
		
		missiondao = new MissionTable();
		stepdao = new StepTable();
		stepSystemdao = new Step_CSTable();
		
		missiondao.droptable();
		missiondao.setUp();
		
		stepdao.droptable();		
		stepdao.setUp();
		
		stepSystemdao.droptable();
		stepSystemdao.setUp();
		
		sosdao = new SoSTable();
		sosdao.droptable();
		sosdao.setUp();
		
		csSoSdao = new CS_SoSTable();
		csSoSdao.droptable();
		csSoSdao.setUp();
		
		}
	
	/**
	 * Inserir sistemas
	 * @param infos
	 */
	public void insertSystem(SystemInformations infos) {
		
		int idsystem = csystemdao.insert(infos.getUrlBase(), infos.getSystemName(), infos.getDescription(), infos.getAgentAddress());
		for(int i =0; i < infos.getFunctions().size(); i ++) {			
			int idtask = taskdao.insert(infos.getFunctions().get(i).getName(), infos.getFunctions().get(i).getLink(), infos.getFunctions().get(i).getMethod() );
			for(int j = 0; j < infos.getFunctions().get(i).getInput().size(); j++) {
				parameterdao.insert(idtask, infos.getFunctions().get(i).getInput().get(j).getName(), infos.getFunctions().get(i).getInput().get(j).getFormat(), "INPUT");
			}
			for(int k = 0; k < infos.getFunctions().get(i).getOutput().size(); k++) {
				parameterdao.insert(idtask, infos.getFunctions().get(i).getOutput().get(k).getName(), infos.getFunctions().get(i).getOutput().get(k).getFormat(), "OUTPUT");
			}		
			taskSystemdao.insert(idsystem, idtask);
		}		
	}	

	/**
	 * Busca o fluxo da missão no BD e retorna como um array de passos
	 * @param idMission
	 * @return ArrayList de passos da missão
	 */
	public ArrayList<Step> getFlow(int idMission) {
		return stepdao.selectAllStepsOfMission(idMission);
	}

	/**
	 * Cria um novo fluxo - retorna o ID do fluxo
	 * @param flow
	 * @param idsos
	 * @param description
	 * @return id da missão criada
	 */// TODO Auto-generated method stub
	public int createMission(ArrayList<Step> flow, int idsos, String name) {
		
		int idMission = missiondao.insert(name, idsos);
		
		for(int i = 0; i < flow.size(); i ++){
			Step s = flow.get(i);
			
			//parâmetros : (String type, String idbpmn,  String description, String incoming, String outcoming, String task, String script, int idmission)
			//TODO VER ORIGEM TASK
			
			if(s instanceof StartEventStep){
				 stepdao.insert( s.getStepType(), s.getIdBpmn(), s.getName(), "", ((StartEventStep) s).getOutgoing(), "TASK" , "", idMission);
			}
			else if(s instanceof EndEventStep){
				stepdao.insert(s.getStepType(), s.getIdBpmn(), s.getName(), ((EndEventStep) s).getIncoming(), "", "TASK" , "", idMission);
			}			
			else if(s instanceof ScriptTaskStep){
				stepdao.insert(s.getStepType(), s.getIdBpmn(), s.getName(), ((ScriptTaskStep) s).getIncoming(), ((ScriptTaskStep) s).getOutgoing(), "TASK" , ((ScriptTaskStep) s).getScript(), idMission);
			}
			else if(s instanceof SequenceFlowStep){
				stepdao.insert( s.getStepType(), s.getIdBpmn(), s.getName(), ((SequenceFlowStep) s).getSourceRef(), ((SequenceFlowStep) s).getTargetRef(), "TASK" , "", idMission);
			}
			else if(s instanceof ExclusiveGatewayStep){
				//TODO implementar 
				//stepdao.insert(idflow, idtype, idbpmn, description, incoming, outcoming, task);
			}						
		}		
		return idMission;		
	}
		
	/**
	 * Inserir passo e vincular ao sistema
	 * @param idFlow
	 * @param pairStepSystem
	 */
	public void insertStepSystem(int idFlow, ArrayList<Pair> pairStepSystem){
		
		for (int temp = 0; temp < pairStepSystem.size(); temp++) {
			stepSystemdao.insert(idFlow, pairStepSystem.get(temp).getSecond(), pairStepSystem.get(temp).getFirst());
		}
	}
	
	public String findFirstTask(int idFlow){
		return stepdao.findFirstStep(idFlow);
	}
	
	public boolean isStepSystemOwner(int idFlow, String idStep, String idSystem){
		return stepSystemdao.find(idFlow, idStep, idSystem);		
	}
	
	public Step findStepByIDBpmn(String idBpmn){
		return stepdao.findStepByIDBpmn(idBpmn);
	}

	public ArrayList<String> getAgentsID(int idSos) {
		ArrayList<String> agentsId = new ArrayList<>();
		ArrayList<Integer> systemId = csSoSdao.getSystemsOfSos(idSos);
		
		for(int i = 0 ; i < systemId.size(); i++) {
			agentsId.add(csystemdao.getAgentID(systemId.get(i)));
		}		
		
		return agentsId;
	}
	
	public ArrayList<SystemInformations> getSystems() {
		return csystemdao.getSystems();
	}
	
	public ArrayList<Task> getTasks() {
		return taskdao.selectAllTask();
	}

	public int createSoS(ArrayList<Pair> parser, String name, String desc) {
		int id = sosdao.insert(name, name, desc);
		
		for(int i = 0; i < parser.size(); i++) {
			
			//TODO Se for diferente de SoSServer
			if(parser.get(i).getFirst() != "A") {					
				int idcsystem = csystemdao.selectByName(parser.get(i).getFirst());
				csSoSdao.insert(id, idcsystem);				
			}
		}			
		return id;
	}

	public ArrayList<Step> selectSteps(int idFlow) {
		ArrayList<Step> steps = stepdao.selectAllStepsOfMissionID(idFlow);		
		return steps;
	}

	public ArrayList<CSystemSos> selectSystems(int idSoS) {
		ArrayList<CSystemSos> cssystem = csSoSdao.selectAllSystemsOfSos(idSoS);		
		return cssystem;
	}

	public ArrayList<CSystem> selectAllCS() {
		ArrayList<CSystem> systems = csystemdao.selectSystems();	
		
		return systems;
	}

	public ArrayList<StepCs> selectAllStepCS() {
		ArrayList<StepCs> stepcs = stepSystemdao.selectAll();
		
		return stepcs;
	}
	
}