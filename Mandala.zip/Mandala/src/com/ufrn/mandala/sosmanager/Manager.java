package com.ufrn.mandala.sosmanager;

import com.ufrn.mandala.sosmanager.dao.SoSManagerDataBaseDAO;

import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

public class Manager {
	
	private ContainerController myContainer;
	private AgentController agent;
	private SoSManagerDataBaseDAO dao;
	
	/**
	 * Construtor do manager
	 * @param myContainer
	 * @param dao
	 */
	public Manager( ContainerController myContainer, SoSManagerDataBaseDAO dao ) {
		
		this.dao = dao;		
		
		this.myContainer = myContainer; 
		try {
			this.agent = myContainer.createNewAgent("Manager", "com.ufrn.mandala.sosmanager.agent.SoSManagerAgent", new Object[] { dao });
			agent.start();
		} catch (StaleProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

	
	
	
}
