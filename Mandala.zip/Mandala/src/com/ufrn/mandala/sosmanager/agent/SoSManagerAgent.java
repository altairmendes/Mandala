package com.ufrn.mandala.sosmanager.agent;

import java.io.IOException;
import java.util.ArrayList;

import com.ufrn.mandala.model.CSystem;
import com.ufrn.mandala.model.CSystemSos;
import com.ufrn.mandala.model.DataBaseBroker;
import com.ufrn.mandala.model.GlobalMission;
import com.ufrn.mandala.model.Pair;
import com.ufrn.mandala.model.PaletteData;
import com.ufrn.mandala.model.StepCs;
import com.ufrn.mandala.model.SystemInformations;
import com.ufrn.mandala.model.step.Step;
import com.ufrn.mandala.sosmanager.dao.SoSManagerDataBaseDAO;
import com.ufrn.mandala.sosserver.SetUpWS;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;

public class SoSManagerAgent extends Agent {

	private static final long serialVersionUID = 1L;
	private SoSManagerDataBaseDAO repository;

	/**
	 * Agente do Manager
	 **/
	protected void setup() {
		// Receber parametros na criação do agente
		Object[] args = getArguments();
		this.repository = (SoSManagerDataBaseDAO) args[0];

		System.out.println("SET UP AGENTE SOS");
		// Linkar endereço dos agentes do sistema
		System.out.println("Agente do : " + this.getLocalName() + " está pronto!");

		addBehaviour(new CyclicBehaviour(this) {

			private static final long serialVersionUID = 1L;

			public void action() {

				ACLMessage receivedMessage = myAgent.receive();

				if (receivedMessage != null) {
					System.out.println("Manager: recebeu mensagem!");
					
					//Recebe mensagens dos Brokers
					if (receivedMessage.getPerformative() == ACLMessage.PROPOSE) {
						SystemInformations sinfos = null;

						try {
							sinfos = (SystemInformations) receivedMessage.getContentObject();

							if (sinfos != null) {
								System.out.println("RECEBI INFOS DO SISTEMA!!!");
								System.out.println(sinfos.print());

								repository.insertSystem(sinfos);

							}
						} catch (Exception e) {
							e.printStackTrace();
						}
							//Recebe a mensagem que vem do SoS Composer
					} 
					else if (receivedMessage.getPerformative() == ACLMessage.INFORM) {
						System.out.println("Manager: Tipo inform");
						
						//Solicitação de Infomação dos sistemas
						if (receivedMessage.getContent().contains("getData")) {
							try {
								System.out.println("Manager: Solicitação de infos");
								PaletteData paletteData = new PaletteData(repository.getSystems(),
										repository.getTasks());
								ACLMessage msgData = receivedMessage.createReply();
								msgData.setContentObject(paletteData);
								send(msgData);
								System.out.println("Manager: Infos Enviadas");
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} 
						//Solicitação para criar nova missão global
						else {
							GlobalMission mission;
							try {
								mission = (GlobalMission) receivedMessage.getContentObject();
								System.out.println("Manager: Criar novo SoS");
								//Cadastrar Missão
								int idSoS = repository.createSoS(mission.getParseToSwinLane(), mission.getName(), mission.getDesc());
								
								int idFlow = repository.createMission(mission.getSteps(), idSoS, mission.getName());
								repository.insertStepSystem(idFlow, mission.getParseToSwinLane());
								
								//TODO Fazer seleção para pegar dados específicos								
								//Variável para enviar para brokers
								ArrayList<Step> steps = repository.selectSteps(idFlow);
								ArrayList<CSystemSos> csSos = repository.selectSystems(idSoS); //Tá retornando null
								ArrayList<StepCs> stepCSTable = repository.selectAllStepCS();
								ArrayList<CSystem> csTable = repository.selectAllCS();
								
								String agentSoSName = mission.getName();
								DataBaseBroker database = new DataBaseBroker(idFlow, idSoS, mission.getName(),mission.getDesc(), agentSoSName, stepCSTable, csTable, steps, csSos);
								
								ACLMessage msgProp = new ACLMessage(ACLMessage.PROPAGATE);
																							
								//Pegar dados dos agentes da missão para enviar
								ArrayList<String> agentsName = repository.getAgentsID(idSoS);
								
								for (int i = 0; i < agentsName.size(); i++) {
									msgProp.addReceiver(new AID(agentsName.get(i), AID.ISLOCALNAME));
									//System.out.println("SOS Manager:" + agentsName.get(i).toString());
								}										
								
								// Mensagem a ser divulgada para todos os Brokers
								msgProp.setContentObject(database);
								send(msgProp);
								
								// TODO Esperar as resposta Reply de todos os sistenas								
								//TODO Subir o WS				

							} catch (UnreadableException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}

					} else if (receivedMessage.getPerformative() == ACLMessage.REQUEST) {

						switch (Integer.parseInt(receivedMessage.getContent())) {
						case 1:
							block();
							break;
						case 2:
							break;
						case 3:
							break;
						default:
							break;
						}
					} else {
						block();
					}
				} else {
					block();
				}
			}
		});

	}

}
