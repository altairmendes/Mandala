package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ufrn.mandala.model.CSystemSos;
import com.ufrn.mandala.model.SystemInformations;

public class CS_SoSTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){	
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE CS_SOS " +
							"(IDSOS 	INTERGER 	NOT NULL," +
							"IDCSYSTEM INTERGER	NOT NULL)";
//							"FOREIGN KEY(ID_SOS) REFERENCES SOS (ID_SOS)," +
//							"FOREIGN KEY(ID_CSYSTEM) REFERENCES CSYSTEM (ID_CSYSTEM))";		
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	
	public void insert(int idsos, int idcsystem){
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");								
			System.out.println("Base de dados aberta com sucesso!!!");			
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM CS_SOS WHERE IDSOS ='"+ idsos + "' AND IDCSYSTEM = '" + idcsystem + "'");
			
			if(!rs.next()) {			
				String sql = "INSERT INTO CS_SOS (IDSOS, IDCSYSTEM) " +
						"VALUES ('"+idsos+"', '"+idcsystem+"')";
				stmt.executeUpdate(sql);				
			}
			
			stmt.close();
			c.commit();
			c.close();
			
		}catch( Exception e){
			e.printStackTrace();
		}
		System.out.println("Dados inseridos!!!");
	}
	
	public ArrayList<Integer> getSystemsOfSos(int idsos) {
		ArrayList<Integer> systems = null;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT IDCSYSTEM FROM CS_SOS WHERE IDSOS = '"+ idsos + "'");
			systems = new ArrayList<Integer> ();
			
			while (rs.next()){
				int id = rs.getInt("idcsystem");
				systems.add(id);
			}			
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return systems;
	}
	
	public ArrayList<CSystemSos> selectAllSystemsOfSos(int idsos) {
		ArrayList<CSystemSos> systems = null;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM CS_SOS WHERE IDSOS = '"+ idsos + "'");
			systems = new ArrayList<CSystemSos>();
			
			while (rs.next()){
				int id = rs.getInt("idcsystem");
				int idSoS = rs.getInt("idsos");
				systems.add(new CSystemSos(idSoS, id));
			}			
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return systems;
	}
	
	

	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'CS_SOS' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
//	public static void main (String [] args){
//		CS_SoSTable cs_sos = new CS_SoSTable();
//		cs_sos.droptable();
//		cs_sos.setUp();
//		cs_sos.insert(1, 99);
//		cs_sos.insert(1, 1);
//		cs_sos.insert(1, 2);
//		cs_sos.insert(1, 3);
//		System.out.println(cs_sos.getSystemsOfSos(1));
//		System.out.println(cs_sos.selectAllSystemsOfSos(1));
//	}
	
}