package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ufrn.mandala.model.CSystem;
import com.ufrn.mandala.model.StepCs;

public class Step_CSTable {

	private Connection c;
	private Statement stmt;
	
	public void setUp() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			stmt = c.createStatement();
			String sql = "CREATE TABLE STEPSYSTEMS " +
						"(IDSTEPSYSTEM INTEGER PRIMARY KEY 	AUTOINCREMENT NOT NULL," +
						"IDMISSION INTEGER NOT NULL," +
						"IDSTEP TEXT NOT NULL," +
						"IDSYSTEM TEXT NOT NULL)";
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Tabela criada com sucesso!!!");
	}

	public void insert(int idMission, String idsteps, String idsystem) {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sql = "INSERT INTO STEPSYSTEMS (IDMISSION, IDSTEP, IDSYSTEM) " + "VALUES ('" + idMission + "','" + idsteps
					+ "','" + idsystem + "')";
			stmt.executeUpdate(sql);
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Registros criados com sucesso!!!");

	}

	public boolean find(int idMission, String idStep, String idSystem) {
		boolean bool = false;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM STEPSYSTEMS WHERE IDMISSION = '" + idMission
					+ "' AND  IDSTEP = '" + idStep + "' AND IDSYSTEM =  '" + idSystem + "'");
			// last() -> true if the cursor is on a valid row; false if there are no rows in
			// the result set
			if (rs.next()) {
				if (rs.getInt(1) > 0) {
					bool = true;
				}
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		return bool;
	}

	public void droptable() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'STEPSYSTEMS' ";
			System.out.println("output : " + stmt.executeUpdate(sqlCommand));
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<StepCs> selectAll() {
		ArrayList<StepCs> stepcs = null;
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM STEPSYSTEMS");
			
			stepcs = new ArrayList<>();
			while (rs.next()){
				int idss = rs.getInt("idstepsystem");
				int idm = rs.getInt("idmission");
				String idstep = rs.getString("idstep");
				String ids = rs.getString("idsystem");
			
				StepCs step = new StepCs(idss, idm, idstep, ids);
				stepcs.add(step);
			}
			
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		
		return stepcs;
	}
}
