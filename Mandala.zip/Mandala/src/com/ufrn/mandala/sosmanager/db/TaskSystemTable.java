package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TaskSystemTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE TASKSYSTEM " +
							"(IDTASKSYSTEM 		 INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
							"IDTASK	  INTEGER NOT NULL," + 
							"IDSYSTEM INTEGER NOT NULL)";
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	

	public void insert(int idSystem, int idTask){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO TASKSYSTEM (IDSYSTEM,IDTASK) " +
						"VALUES ('"+idSystem+"','"+ idTask+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			 
		}
		System.out.println("Registros criados com sucesso!!!");
	}
	
	public void droptable() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'TASKSYSTEM' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
//	public void selectAllTask(){
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
//			System.out.println("Base de dados aberta com sucesso!!!");
//			c.setAutoCommit(false);
//			stmt = c.createStatement();
//			
//			
//			ResultSet rs = stmt.executeQuery("SELECT * FROM TASK");
//			while (rs.next()){
//				int idtask = rs.getInt("idtask");
//				String description = rs.getString("description");
//				
//				System.out.println("IDSOS = " + idtask);
//				System.out.println("DESCRIPTION = " + description);
//			}
//			rs.close();			
//			stmt.close();
//			c.close();
//			
//		} catch ( Exception e ){
//			System.err.println(e.getClass().getName() + ": " +e.getMessage());
//			 
//		}
//		System.out.println("Opera��o realizada com sucesso!!!");		
//	}
//	
//	public void droptable(){
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
//			c.setAutoCommit(false);
//			
//			stmt = c.createStatement();
//			String sqlCommand = "DROP TABLE IF EXISTS 'TASK' ";
//
//			System.out.println("output : " + stmt.executeUpdate(sqlCommand));
//
//			stmt.close();
//			c.commit();     
//			
//			c.close();			
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
//		System.out.println("Tabela destru�da!!!");
//	}
	
//	public static void main(String [] args){
//		TaskDBManager t = new TaskDBManager();
//		t.droptable();
//		t.setUp();
//		t.insert("Task something....");
//		t.insert("Task other somethings....");
//		t.selectAllTask();
//		t.droptable();
//	}
}
