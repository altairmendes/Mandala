package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ufrn.mandala.model.CSystem;
import com.ufrn.mandala.model.CSystemSos;
import com.ufrn.mandala.model.SystemInformations;

public class CSystemTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE CSYSTEM " +
					"(IDCSYSTEM  INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
					"URL 	     TEXT 				NOT NULL," +
					"DESCRIPTION TEXT               NOT NULL," +
					"AGENT       TEXT               NOT NULL," +
					"NAME        TEXT               NOT NULL)";						
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());			
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public int insert(String url, String name, String desc, String agent ){
		int id = -1;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO CSYSTEM (URL, NAME, DESCRIPTION, AGENT) " +
						"VALUES ('"+url+"','"+name+"','"+desc +"','"+ agent + "')";
			
			stmt.executeUpdate(sql);
			ResultSet rs = stmt.getGeneratedKeys();
			rs.next();
			id = rs.getInt(1);
			
			stmt.close();
			c.commit();
			c.close();			
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}		
		System.out.println("Registros criados com sucesso!!!");
		return id;
	}
	
	public String getAgentID(int id){
		String agent = null;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM CSYSTEM where idcsystem ='"+ id +"'");
			while (rs.next()){
				agent = rs.getString("agent");
				System.out.println("ADDRESS = " + agent);
			}			
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
		}
		return agent;
	}
	
	public int selectByName(String name){
		int idcsystem = 0;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT idcsystem FROM CSYSTEM where name ='"+ name +"'");
			while (rs.next()){
				 idcsystem = rs.getInt("idcsystem");
				System.out.println("IDCSYSTEM = " + idcsystem);				
			}			
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return idcsystem;
	}

	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'CSYSTEM' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	public ArrayList<SystemInformations> getSystems() {
		ArrayList<SystemInformations> systems = null;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM CSYSTEM");
			systems = new ArrayList<SystemInformations> ();
			
			while (rs.next()){
				int id = rs.getInt("idcsystem");
				String agent = rs.getString("agent");
				String url = rs.getString("url");
				String name = rs.getString("name");
				String desc = rs.getString("description");
				SystemInformations infos = new SystemInformations(id, name, desc, agent, url);
				systems.add(infos);
			}			
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return systems;
	}

	public ArrayList<CSystem> selectSystems() {
		ArrayList<CSystem> systems = null;
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM CSYSTEM");
			systems = new ArrayList<CSystem> ();
			
			while (rs.next()){
				int id = rs.getInt("idcsystem");
				String agent = rs.getString("agent");			
				String name = rs.getString("name");				
				CSystem system = new CSystem(id, agent, name);
				systems.add(system);
			}
			rs.close();			
			stmt.close();
			c.close();
		}catch(Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return systems;
	}


	
//	public static void main(String [] agrs){
//		CSystemTable cs = new CSystemTable();
//		cs.droptable();
//		cs.setUp();
//		int id = cs.insert("end123", "ambulancia", "sdfffff", "ssss");
//		int id1 = cs.insert("end123", "hospital", "sdfffff", "ssss");	
//		System.out.println(id);
//		System.out.println(id1);
//		id = cs.selectByName("hospital");	
//		System.out.println("Id do hospital:"+ id);
//		cs.droptable();
//	}
}
