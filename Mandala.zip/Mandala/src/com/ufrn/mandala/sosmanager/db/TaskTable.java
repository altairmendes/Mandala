package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import com.ufrn.mandala.model.Task;

public class TaskTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE TASK " +
							"(IDTASK 		 INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
							"NAME	 TEXT NOT NULL,"+
							"PATH	 TEXT NOT NULL,"+
							"TYPE    TEXT NOT NULL)";
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public int insert(String name, String path, String type){
		int id = -1;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO TASK (NAME, PATH, TYPE) " +
					"VALUES ('"+name+"','"+ path + "','"+ type +"')";
			stmt.executeUpdate(sql);
			ResultSet rs = stmt.getGeneratedKeys();
			rs.next();
			id = rs.getInt(1);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			 
		}
		System.out.println("Registros criados com sucesso!!!");
		return id;
	}
	
	public ArrayList<Task> selectAllTask(){
		ArrayList<Task> tasks = null;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			tasks = new ArrayList<Task>();
			ResultSet rs = stmt.executeQuery("SELECT * FROM TASK");
			while (rs.next()){
				int idtask = rs.getInt("idtask");
				String name = rs.getString("name");
				String path = rs.getString("path");
				String type = rs.getString("type");
				
				Task task = new Task(idtask, name, type);
				tasks.add(task);
			}
			rs.close();			
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			 
		}
		System.out.println("Opera��o realizada com sucesso!!!");
		return tasks;
	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'TASK' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		System.out.println("Tabela destru�da!!!");
	}
	
//	public static void main(String [] args){
//		TaskDBManager t = new TaskDBManager();
//		t.droptable();
//		t.setUp();
//		t.insert("Task something....");
//		t.insert("Task other somethings....");
//		t.selectAllTask();
//		t.droptable();
//	}
}
