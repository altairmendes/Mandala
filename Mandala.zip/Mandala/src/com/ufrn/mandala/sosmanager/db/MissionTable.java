package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MissionTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE MISSION " +
							"(IDMISSION 		 INTEGER PRIMARY KEY	AUTOINCREMENT NOT NULL," +
							"DESCRIPTION 		 TEXT 			NOT NULL," +
							"IDSOS 			 	 INTEGER 		NOT NULL)";
							//"FOREIGN KEY(IDSOS) REFERENCES SOS (IDSOS))";
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public int insert(String description, int idsos){
		int id = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO MISSION (DESCRIPTION, IDSOS) " +
						"VALUES ('"+description+"', '"+idsos+"')";
			stmt.executeUpdate(sql);
			
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()) {
			  id = rs.getInt(1);
			}
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
		return id;
	}
	
	public void selectAllMission(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM MISSION");
			while (rs.next()){
				int idmission = rs.getInt("idmission");
				int idsos = rs.getInt("idsos");
				String description = rs.getString("description");
				
				System.out.println("IDMISSION = " + idmission);
				System.out.println("IDSOS = " + idsos);
				System.out.println("DESCRIPTION = " + description);
			}
			rs.close();			
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Opera��o realizada com sucesso!!!");		
	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'MISSION' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
//	public static void main(String[] args){
//		MissionTable m = new MissionTable();
//		m.droptable();
//		m.setUp();
//		int id = m.insert("descri��o", 1);
//		System.out.println("ID: " + id);
//		int id1 = m.insert("descri��o", 1);
//		System.out.println("ID: " + id1);
//		int id2 = m.insert("descri��o", 1);
//		System.out.println("ID: " + id2);
//		m.selectAllMission();
//		System.out.println("A tabela ser� destru�da!");
//		
//	}
}