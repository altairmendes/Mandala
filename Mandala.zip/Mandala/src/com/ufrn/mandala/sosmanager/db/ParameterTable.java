package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ParameterTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE PARAMETERS " +
							"(IDTASK 		 INTEGER  NOT NULL," +
							"NAME	 TEXT NOT NULL,"+
							"FORMAT	 TEXT NOT NULL,"+
							"ISINPUT TEXT NOT NULL)";
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public void insert(int idTask, String name, String format, String inORout){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			boolean isInput = false;
			if (inORout.equals("INPUT")) {
				isInput = true;
			}
			String sql = "INSERT INTO PARAMETERS (IDTASK,NAME,FORMAT, ISINPUT) " +
						"VALUES ('"+idTask+"','"+name+"','"+format +"','"+ isInput + "')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
	}

	public void droptable() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'PARAMETERS' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
