package com.ufrn.mandala.sosmanager.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SoSTable {
	private Connection c;
	private Statement stmt;
	
	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			
			stmt = c.createStatement();
			String sql = "CREATE TABLE SOS " +
					"(IDSOS 			INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
					" NAME 				TEXT 	NOT NULL," +
					" AGENTADDRESS		TEXT 	NOT NULL," +		
					" DESCRIPTION		TEXT	NOT NULL)";

			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public int insert(String name, String agentAddress, String desc ){
		int id = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO SOS (NAME, AGENTADDRESS, DESCRIPTION) " +
						"VALUES ('"+name+"', '"+agentAddress+"', '"+desc+"')";
			stmt.executeUpdate(sql);
			
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()) {
			  id = rs.getInt(1);
			}
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
		return id;
	}
	
	public void select(String sosName){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM SOS where name='"+sosName+"'");
			while (rs.next()){
				int idsos = rs.getInt("idsos");
				String name = rs.getString("name");
				String description = rs.getString("description");
				System.out.println("IDSOS = " + idsos);
				System.out.println("NAME = " + name);
				System.out.println("DESCRIPTION = " + description);
				System.out.println();
			}
			//TODO � para assumir que o atributo recebido sempre vai est� na tabela?
			
			rs.close();			
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Opera��o realizada com sucesso!!!");
	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:sosmanager.db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'SOS' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
//	public static void main(String [] args){
//		SoSTable s = new SoSTable();
//		s.droptable();
//		s.setUp();
//		int id = s.insert("SoS way truck", "ambulancia", "SoS que faz o trajeto do caminh�o de lixo");
//		int id1 = s.insert("SoS way truck", "ambulancia", "SoS que faz o trajeto do caminh�o de lixo");
//		System.out.println("ID: " + id + "ID1: "+ id1);
//		s.droptable();
//	}
}
