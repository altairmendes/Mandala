package com.ufrn.mandala.broker.form;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.ufrn.mandala.model.SystemInformations;
import com.ufrn.mandala.model.Function.Parameter;

public class Form extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfFunctions;
	private JTextField tfName;
	private JTextField tfDescription;
	private JTextField tfAgent;
	private JTextField tfPath;
	private JTextField tfURL;
	private JTextField tfParameters;
	private SystemInformations infos;
	private Notifier notifier;
	
	/* Observer Pattern */
	 public class Notifier extends Observable {
        public Notifier() {
        }

        public void notifyMyObservers(SystemInformations infos) {
            this.setChanged();
            this.notifyObservers(infos);
        }
	 }	

//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Form frame = new Form();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
//  public Form() {
	
	public Form(Observer o) {
		notifier = new Notifier();
		notifier.addObserver(o);
		
		
	 
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 829, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
//Cria os modelos de lista a serem inseridos no objeto List		
		final DefaultListModel<String> listModelFunctions = new DefaultListModel<>();
		final DefaultListModel<String> listModelType = new DefaultListModel<>();
		final DefaultListModel<String> listModelFormat = new DefaultListModel<>();
		final DefaultListModel<String> listModelPath = new DefaultListModel<>();
		final DefaultListModel<String> listModelParameters = new DefaultListModel<>();		
		final DefaultListModel<String> listModelInOut = new DefaultListModel<>();
		
//Cria as listas e associa os modelos		
		final JList<String> listFunctions = new JList<String>(listModelFunctions);
		listFunctions.setBounds(10, 140, 223, 140);
		contentPane.add(listFunctions);
		
		final JList<String> listType = new JList<String>(listModelType);
		listType.setBounds(245, 140, 93, 140);
		contentPane.add(listType);
		
		final JList<String> listFormat = new JList<String>(listModelFormat);
		listFormat.setBounds(725, 140, 93, 140);
		contentPane.add(listFormat);
		
		final JList<String> listPath = new JList<String>(listModelPath);
		listPath.setBounds(351, 140, 122, 140);
		contentPane.add(listPath);
		
		final JList<String> listParameters = new JList<String>((listModelParameters));
		listParameters.setBounds(493, 140, 122, 140);
		contentPane.add(listParameters);
		
		final JList<String> listInOut = new JList<String>(listModelInOut);
		listInOut.setBounds(628, 140, 84, 140);
		contentPane.add(listInOut);
		
	//Cria os demais objetos que serão inseridos no formulário		
		final JComboBox<String> cbInOut = new JComboBox<String>();
		cbInOut.setEditable(true);
		cbInOut.setModel(new DefaultComboBoxModel<String>(new String[] {"In", "Out"}));
		cbInOut.setBounds(628, 110, 84, 27);
		contentPane.add(cbInOut);		

		final JComboBox<String> cbType = new JComboBox<String>();
		cbType.setForeground(new Color(0, 0, 0));
		cbType.setEditable(true);
		cbType.setModel(new DefaultComboBoxModel<String>(new String[] {"GET", "POST"}));
		cbType.setBounds(245, 111, 93, 27);
		contentPane.add(cbType);
		
		final JComboBox<String> cbFormat = new JComboBox<String>();
		cbFormat.setEditable(true);
		cbFormat.setModel(new DefaultComboBoxModel<String>(new String[] {"INTEGER", "TEXT", "BOOLEAN", "REAL"}));
		cbFormat.setBounds(725, 111, 93, 27);
		contentPane.add(cbFormat);
		
		tfPath = new JTextField();
		tfPath.setBounds(346, 110, 130, 26);
		contentPane.add(tfPath);
		tfPath.setColumns(10);
		
		JLabel lblFunctions = new JLabel("Functions");
		lblFunctions.setForeground(new Color(0, 128, 128));
		lblFunctions.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFunctions.setBounds(11, 96, 145, 16);
		contentPane.add(lblFunctions);
		
		tfFunctions = new JTextField();
		tfFunctions.setBounds(7, 110, 230, 26);
		contentPane.add(tfFunctions);
		tfFunctions.setColumns(10);
		
		JLabel lblName = new JLabel("System Name");
		lblName.setForeground(new Color(0, 128, 128));
		lblName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblName.setBounds(9, 52, 93, 16);
		contentPane.add(lblName);
		
		tfName = new JTextField();
		tfName.setBounds(6, 67, 130, 26);
		contentPane.add(tfName);
		tfName.setColumns(10);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setForeground(new Color(0, 128, 128));
		lblDescription.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDescription.setBounds(162, 52, 79, 16);
		contentPane.add(lblDescription);
		tfDescription = new JTextField();
		tfDescription.setBounds(158, 67, 364, 26);
		contentPane.add(tfDescription);
		tfDescription.setColumns(10);
		
		tfAgent = new JTextField();
		tfAgent.setBounds(545, 67, 130, 26);
		contentPane.add(tfAgent);
		tfAgent.setColumns(10);
		
		JLabel lblAgent = new JLabel("Agent Name");
		lblAgent.setForeground(new Color(0, 128, 128));
		lblAgent.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAgent.setBounds(549, 52, 127, 16);
		contentPane.add(lblAgent);
		
		JLabel lblType = new JLabel("Type");
		lblType.setForeground(new Color(0, 128, 128));
		lblType.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblType.setBounds(248, 95, 61, 16);
		contentPane.add(lblType);
				
		JLabel lblFormat = new JLabel("Format");
		lblFormat.setForeground(new Color(0, 128, 128));
		lblFormat.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFormat.setBounds(726, 95, 61, 16);
		contentPane.add(lblFormat);
	
		
		JLabel lblPath = new JLabel("Path");
		lblPath.setForeground(new Color(0, 128, 128));
		lblPath.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPath.setBounds(356, 95, 61, 16);
		contentPane.add(lblPath);
		
		JLabel lblInout = new JLabel("In/Out");
		lblInout.setForeground(new Color(0, 128, 128));
		lblInout.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblInout.setBounds(632, 96, 61, 16);
		contentPane.add(lblInout);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 43, 869, 12);
		contentPane.add(separator);
		
		tfParameters = new JTextField();
		tfParameters.setColumns(10);
		tfParameters.setBounds(488, 110, 130, 26);
		contentPane.add(tfParameters);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setOrientation(SwingConstants.VERTICAL);
		separator_4.setBounds(478, 112, 12, 170);
		contentPane.add(separator_4);
		
		JLabel lblParameters = new JLabel("Parameters");
		lblParameters.setForeground(new Color(0, 128, 128));
		lblParameters.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblParameters.setBounds(498, 95, 93, 16);
		contentPane.add(lblParameters);
		
//Define as propriedades quando o Botão Save é acionado	
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				//Faz a seleção de todos os elementos das listas para envio ao SoS Manager
				listFunctions.setSelectionInterval(0, listModelFunctions.size()-1);
				listType.setSelectionInterval(0, listModelType.size()-1);
				listFormat.setSelectionInterval(0, listModelFormat.size()-1);
				listPath.setSelectionInterval(0, listModelPath.size()-1);
				listParameters.setSelectionInterval(0, listModelParameters.size()-1);
				listInOut.setSelectionInterval(0, listModelInOut.size()-1);
				
				//Add system infos 
				infos = new SystemInformations(tfName.getText(), tfDescription.getText(), tfAgent.getText(), tfURL.getText());
					
				
				for (int i = 0; i < listFunctions.getSelectedValuesList().size(); i++){
					System.out.println(i + " - Nome: "+listFunctions.getSelectedValuesList().get(i) + " - Type: " +listType.getSelectedValuesList().get(i) +  " - Formato:" +listFormat.getSelectedValuesList().get(i) + " -Path: " +listPath.getSelectedValuesList().get(i) + " - Param: " + listParameters.getSelectedValuesList().get(i) + " - In/Out " + listInOut.getSelectedValuesList().get(i));
					int funcID = infos.getFunctionID(listFunctions.getSelectedValuesList().get(i).toString());
					if ( funcID >= 0) {
						//Function already exits
						if (listInOut.getSelectedValuesList().get(i) == "In") {
							Parameter par = new Parameter(listParameters.getSelectedValuesList().get(i).toString(), listFormat.getSelectedValuesList().get(i).toString());
							infos.getFunctions().get(funcID).getInput().add(par);							
						}
						else if (listInOut.getSelectedValuesList().get(i) == "Out") {
							Parameter par = new Parameter(listParameters.getSelectedValuesList().get(i).toString(), listFormat.getSelectedValuesList().get(i).toString());
							infos.getFunctions().get(funcID).getOutput().add(par);
						}
					}
					else {
						funcID = infos.newFunction(listFunctions.getSelectedValuesList().get(i).toString(), listPath.getSelectedValuesList().get(i).toString(), listType.getSelectedValuesList().get(i).toString());
						if (listInOut.getSelectedValuesList().get(i) == "In") {
							Parameter par = new Parameter(listParameters.getSelectedValuesList().get(i).toString(), listFormat.getSelectedValuesList().get(i).toString());
							infos.getFunctions().get(funcID).getInput().add(par);							
						}
						else if (listInOut.getSelectedValuesList().get(i) == "Out") {
							Parameter par = new Parameter(listParameters.getSelectedValuesList().get(i).toString(), listFormat.getSelectedValuesList().get(i).toString());
							infos.getFunctions().get(funcID).getOutput().add(par);
						}
						
					}
				}
				notifier.notifyMyObservers(infos);			
			}
			
		});
		btnNewButton.setBounds(706, 283, 117, 29);
		contentPane.add(btnNewButton);


//Define as propriedades quando o Botão Add é acionado
		JButton btnNewButton_1 = new JButton("Add");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//adiciona os elementos digitados nos componentes do formulário
				listModelFunctions.addElement(tfFunctions.getText());  
				listModelType.addElement(cbType.getSelectedItem().toString());
				listModelFormat.addElement(cbFormat.getSelectedItem().toString());
				listModelPath.addElement(tfPath.getText());
				listModelParameters.addElement(tfParameters.getText());
				listModelInOut.addElement(cbInOut.getSelectedItem().toString());
				
				//limpa o texto digitado nos textfields
				//tfFunctions.setText("");
				//tfURL.setText("");
				
				//coloca o foco no textfield de Funções após a adição dos elementos na lista
				tfFunctions.requestFocusInWindow();
				
			}
		});
		btnNewButton_1.setBounds(7, 283, 117, 29);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("/home/mandala/Área de Trabalho/Mandala/src/com/ufrn/mandala/broker/form/mandala3.png"));
		lblNewLabel.setBounds(11, 0, 251, 45);
		contentPane.add(lblNewLabel);
		
		JLabel lblUrl = new JLabel("URL");
		lblUrl.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblUrl.setForeground(new Color(0, 128, 128));
		lblUrl.setBounds(692, 51, 61, 16);
		contentPane.add(lblUrl);
		
		tfURL = new JTextField();
		tfURL.setBounds(688, 67, 130, 26);
		contentPane.add(tfURL);
		tfURL.setColumns(10);
		
	}
}
