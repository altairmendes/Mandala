package com.ufrn.mandala.broker.systemInterface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONObject;

/**
 * @author stefano
 *
 */
public abstract class AbstractSystemInterface {
	
	public AbstractSystemInterface(){
		
	}
	
private final String USER_AGENT = "Mozilla/5.0";
 
	
	/**
	 * Método genérico para solicitar get
	 * 
	 * @param url   url da API
	 * @return   Retorno da requisição
	 * @throws Exception
	 */
	protected String sendGet(String url) throws Exception {		
		 
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
 
		// optional default is GET
		con.setRequestMethod("GET");
 
		//add request header
		con.setRequestProperty("User-Agent", USER_AGENT);
 
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);
 
		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		
		String inputLine;
		StringBuffer response = new StringBuffer();
 
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
 
		//print result
		System.out.println(response.toString());
		
		return response.toString();
 
	}
		
	// HTTP POST request
	/**
	 * Método genérico para solicitar post
	 * 
	 * @param url   url da API
	 * @param content conteudo do post
	 * @return   Retorno da requisição
	 * @throws Exception
	 */
	protected String sendPost(String url, String content) throws Exception {
		
		String result = null;
		
		try {
			URL obj = new URL(url);		
	        HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
	        conn.setConnectTimeout(5000);
	        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        conn.setDoOutput(true);
	        conn.setDoInput(true);
	        conn.setRequestMethod("POST");
	
	        conn.setDoOutput(true);
	        conn.setRequestMethod("POST");
	        conn.setRequestProperty("Content-Type", "application/json");	        
	
	        OutputStream os = conn.getOutputStream();
	        os.write(content.getBytes());
	        os.flush();
	
	        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
	            throw new RuntimeException("Failed : HTTP error code : "
	                + conn.getResponseCode());
	        }
	
	        BufferedReader br = new BufferedReader(new InputStreamReader(
	                (conn.getInputStream())));
	
	        String inputLine;
			StringBuffer response = new StringBuffer();
	 
			while ((inputLine = br.readLine()) != null) {
				response.append(inputLine);
			}
			br.close();
	 
			//print result
			System.out.println(response.toString());
	        
	        conn.disconnect();
	        result = response.toString();
	        
      } catch (MalformedURLException e) {
        e.printStackTrace();

      } catch (IOException e) {
        e.printStackTrace();

     }
		return result;
	}	
		
	/**
	 * Método a ser implementado pela classe filha
	 * @param script
	 * @param parametersList
	 * @return
	 */
	public abstract JSONObject execute(String script, JSONObject parameters);
	
	
}
