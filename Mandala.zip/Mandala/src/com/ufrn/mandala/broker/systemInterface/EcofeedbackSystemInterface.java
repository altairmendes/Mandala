package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import org.json.JSONObject;

public class EcofeedbackSystemInterface extends AbstractSystemInterface{
	
	private String urlbase = "http://localhost:8180/Ecofeedback";
	
	public EcofeedbackSystemInterface() {

	}	

	public JSONObject execute(String script, JSONObject parameters) {
		if(script.equals("/api/container/")){			
			try {
				//TODO tratar os parâmetros
				return new JSONObject().accumulate("Chave", getInfosContainers(urlbase+script, parameters )); 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}			
		return "ERRO POST ECOFEEDBACK!";
		
	}
	
	public String getInfosContainers(String url ) throws Exception{		
		String r = sendPost(url, (String) parametersList.get(0));
		System.out.println(r);
		return r;
		
	}

}
