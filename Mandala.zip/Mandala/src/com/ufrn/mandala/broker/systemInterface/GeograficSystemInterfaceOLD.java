package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;
import java.util.List;

//import javax.json.JsonArray;

//import org.codehaus.jettison.json.JSONArray;
//import org.codehaus.jettison.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import com.google.gson.*;
import com.ufrn.mandala.broker.systemInterface.HospitalSystemInterfaceOLD;

import com.ufrn.mandala.broker.agent.SystemAgent;



public class GeograficSystemInterfaceOLD extends AbstractSystemInterface{

	private String urlbase = "http://localhost/api/consulta.php/";
	
	@Override
	public JSONObject execute(String script, JSONObject parameters) {
//		if(script.equals("/consulta/")){			
//			return new JSONObject().accumulate("chave", calcularDistancia(parameters.getInt("cepOrigem"),parameters.getInt("cepDestino")));
//		}
//		
	//	if(script.equals("/melhorHospital/")){
			//return new JSONObject().accumulate(calcularMelhorHospital(parameters.getInt("cepOrigem"),parameters.getInt("cepOrigem")));
	
		String valorCep = calcularMelhorHospital(59022150,new HospitalSystemInterfaceOLD().listaCeps);
		
		//JSONArray json = new JSONArray
		//String resultadoCEP = calcularMelhorHospital(59022150, new SystemAgent().getJsonGlobal());
		
		//return new JSONObject().accumulate("resposta",calcularMelhorHospital(59022150,new SystemAgent().getJsonGlobal()));
		return new JSONObject().accumulate("resposta",valorCep);
		
		//	}
		
		//return null;
	}

	private int calcularDistancia (int cepOrigem, int cepDestino) {
		try {
			return Integer.parseInt(sendGet(urlbase+cepOrigem+"/"+cepDestino+"/"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return 0;		
	}
	
	//Comportamento Emergente
	private String calcularMelhorHospital (int cepOrigem, String lista){
		//Transformar JSON em lista de inteiros
		ArrayList<Integer> listaCeps = new ArrayList<Integer>();
		JSONArray json =  new JSONArray(lista);
		for (int i =0; i<json.length(); i++) {
			String cep = json.getJSONObject(i).getString("Cep");
			listaCeps.add(Integer.parseInt(cep));
		}
		
		int cepMenor = listaCeps.get(0);
		int menorDistancia = calcularDistancia(cepOrigem, cepMenor);
		for(int i =1; i < listaCeps.size(); i ++) {
			int distancia = calcularDistancia(cepOrigem, listaCeps.get(i));
			if( distancia < menorDistancia) {
				cepMenor = listaCeps.get(i);
				menorDistancia = distancia;
			}
		}
		return ""+cepMenor;		
	}
	
	
	

}
