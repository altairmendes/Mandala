package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import org.json.JSONObject;

public class RoutesSystemInterface extends AbstractSystemInterface {
	
	private String urlbase = "http://localhost:8180/Rotas";

	public RoutesSystemInterface() {
				
	}
	
	public JSONObject execute(String script, JSONObject parameters) {
		if(script.equals("/api/rotas/")){
			try {
				int i = generateRoutes(urlbase + script, (String) parameters.get("chave"));
				return new JSONObject().accumulate("chave", i);				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}			
		return null;
		
	}
	
	public int generateRoutes(String url, String s) throws Exception{
		sendPost(url, s);
		return 0;
	}


}
