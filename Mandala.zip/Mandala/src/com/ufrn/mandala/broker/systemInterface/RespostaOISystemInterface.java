package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;
import com.google.gson.*;

import org.json.JSONObject;

public class RespostaOISystemInterface extends AbstractSystemInterface{
	
	private String urlbase = "http://localhost:8080/TesteMandala/rest/mandala/resposta3/Altair";
	
	public RespostaOISystemInterface() {

	}	
	


	public JSONObject execute(String script, JSONObject parameters) {
		
		
		try {
			return new JSONObject().accumulate("oi",getInfosContainers(urlbase) );
			
			
		}catch (Exception e){
			
		}
		return null;
		
		//TODO verificar script. Está vazio no banco
//		if(script.equals("/rest/mandala/resposta1")){			
//			try {
//				return getInfosContainers(urlbase+script, parametersList );
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}		
//		}			
//		return "ERRO POST ECOFEEDBACK!";
		
	}
	
	public String getInfosContainers(String url) throws Exception{		
		String r = sendGet(url);
		System.out.println(r);
		return r;
		
	}
	
	
//	public static void main(String[] args) {
//		RespostaOISystemInterface rOI = new RespostaOISystemInterface();
//		System.out.println(rOI.execute("",null));
//	}
	

}
