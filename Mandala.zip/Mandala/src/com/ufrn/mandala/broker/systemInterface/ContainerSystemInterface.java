package com.ufrn.mandala.broker.systemInterface;


import java.util.ArrayList;

import org.json.JSONObject;

public class ContainerSystemInterface extends AbstractSystemInterface{
	
	//TODO RECEBER REPOSITORY
	private String urlbase = "http://10.7.129.10/system3/api/index.php";
	
	
	public ContainerSystemInterface() {		
	}	
		
	public JSONObject execute(String script, JSONObject) {
		if(script.equals("/container/vidro")){
			//TODO Pegar tipo de mateiral
			if(true){
				return new JSONObject().accumulate("chave", getFullContainersVidro(urlbase+ script));
			}		
		}			
		return "";
		
	}
		
	
	private String getFullContainersVidro(String url){
		String result = "404 - PAGE NOT FOUND!";
		
		try {
			result = sendGet(url);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
		return result;
	}

	
//	private String getFullContainers(String url, int id){
//		String result = "404 - PAGE NOT FOUND!";
//		
//		try {
//			result = sendGet(url+"/:"+id);
//		} catch (Exception e) {			
//			e.printStackTrace();
//		}
//		
//		return result;
//	}
//	
//	public String getFUnction(String api, int id1, int id2, int id3){
//		
//		return "";
//		
//	}		
	
}
