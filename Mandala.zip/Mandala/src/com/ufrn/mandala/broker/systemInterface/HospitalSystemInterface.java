package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import org.json.JSONObject;
import java.io.*;

public class HospitalSystemInterface extends AbstractSystemInterface{

	@Override
	public JSONObject execute(String script, JSONObject parameters) {
		//if(script.equals("/listar/comleitos/")){
			return new JSONObject().accumulate("chave", listarHospitalComLeitos());
			
		//	JSONArray json = new JSONArray(listarHospitalComLeitos().toString());
		//}
		//return null;
	}
	
	private String listarHospitalComLeitos() {
		try {
			return sendGet("http://192.168.0.107:8080/ControledeHospitaisREST/rest/hospitais/listar/comleitos/");
			
			//JSONArray json = new JSONArray(IOUtils.)
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}


}
