package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import org.json.JSONObject;

public class AmbulanciaSystemInterface extends AbstractSystemInterface{

	@Override
	public JSONObject execute(String script, JSONObject parametersList) {
	//	if(script.equals("/chamado/cadastrar/")){
			//return new JSONObject().accumulate("chave", criarChamado((int)parametersList.get(0), (int)parametersList.get(1)));
		return new JSONObject().accumulate("chave", criarChamado(59022150, 59050150));
	//	}
	//	return null;
	}
	
	private String criarChamado(int cepOrigem, int cepDestino) {
		try {
			//ArrayList <> ceps = new ArrayList<>();
			
			//return sendPost("http://192.168.0.107:8080/AMBFINAL/rest/ambulancia/chamado/cadastrar/", Integer.toString(cepOrigem), Integer.toString(cepDestino));
			return sendGet("http://192.168.0.107:8080/AMBFINAL/rest/ambulancia/chamado/cadastrar/59022150/59031050");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

}
