package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import org.json.JSONObject;
import com.ufrn.mandala.broker.agent.SystemAgent;
import com.google.gson.*;

public class RespostaOKSystemInterface extends AbstractSystemInterface{
	
	private String urlbase = "http://localhost:8080/TesteMandala/rest/mandala/resposta2";
	
	public RespostaOKSystemInterface() {

	}	

	public JSONObject execute(String script, JSONObject parameters) {
//		if(script.equals("/rest/mandala/resposta2")){			
//			try {
//				return getInfosContainers(urlbase+script, parametersList );
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}		
//		}			
//		return "ERRO POST ECOFEEDBACK!";
		try {
			
				Gson gson = new Gson();
			
			return new JSONObject().accumulate("ok",getInfosContainers(urlbase));
			
		//	String resultado = gson.toJson(new SystemAgent().getJsonGlobal());
			
			//return new JSONObject().accumulate("oi", resultado);
			
		//	String resultado = new SystemAgent().getJsonGlobal();
			

			
		}catch (Exception e){
			
		}
		return null;
		
	}
	
	public String getInfosContainers(String url) throws Exception{		
		String r = sendGet(url);
		return r;
		
	}
	
//	public static void main(String[] args) {
//		RespostaOKSystemInterface rOI = new RespostaOKSystemInterface();
//		System.out.println(rOI.execute("",null));
//	}

}
