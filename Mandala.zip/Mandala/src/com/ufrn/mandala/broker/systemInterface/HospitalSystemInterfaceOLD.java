package com.ufrn.mandala.broker.systemInterface;

import java.util.ArrayList;

import java.util.List;

import org.apache.commons.io.*;

import org.json.JSONObject;
import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.*;

public class HospitalSystemInterfaceOLD extends AbstractSystemInterface{
	
	public static String listaCeps = ""; 

	@Override
	public JSONObject execute(String script, JSONObject parameters) {
		//if(script.equals("/listar/comleitos/")){
		
			return new JSONObject().accumulate("Cep",listarHospitalComLeitos().toString());
			
		//	JSONArray json = new JSONArray(listarHospitalComLeitos().toString());
		//}
		//return null;
	}
	
	private String listarHospitalComLeitos() {
		try {
			//return sendGet("http://192.168.0.107:8080/ControledeHospitaisREST/rest/hospitais/listar/comleitos/");
			//List<String> listaCeps = new ArrayList<String>();
		//	System.out.println("Antes de listar ceps");

//			
			listaCeps = sendGet("http://192.168.0.107:8080/ControledeHospitaisREST/rest/hospitais/listar/comleitos/");
			
			return listaCeps;
			//JSONArray json = new JSONArray(sendGet("http://192.168.0.107:8080/ControledeHospitaisREST/rest/hospitais/listar/comleitos/"));
//			for (int i=0;i<json.length();i++) {
//				JSONObject hospitais = json.getJSONObject(i);
//				String cep = hospitais.getString("Cep");
//				listaCeps.add(cep);
//				
//			}
//			System.out.println("Lista de Ceps:"+listaCeps);
//			return listaCeps;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	 


}
