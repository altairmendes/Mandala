package com.ufrn.mandala.broker.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CS_SoSTable {
	private Connection c;
	private Statement stmt;
	private String nameDB;
	
	public CS_SoSTable(String nameDB) {
		this.nameDB = nameDB;
	}	
	
	public void setUp(){	
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE CS_SOS " +
							"(IDSOS 	INTERGER 	NOT NULL," +
							"IDCSYSTEM INTERGER	NOT NULL)";	
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	
	public void insert(int idsos, int idcsystem){
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");								
			System.out.println("Base de dados aberta com sucesso!!!");			
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO CS_SOS (IDSOS, IDCSYSTEM) " +
						"VALUES ('"+idsos+"', '"+idcsystem+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		}catch( Exception e){
			e.printStackTrace();
		}
		System.out.println("Dados inseridos!!!");
	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'CS_SOS' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public ArrayList<Integer> getConstituentSistems(int sosID) {
		
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT IDCSYSTEM FROM CS_SOS where IDSOS ='" + sosID + "'");
			ArrayList<Integer> systemsIDS = new ArrayList<>();
			
			while (rs.next()) {
				int idcsystem = rs.getInt("idcsystem");
				systemsIDS.add(idcsystem);
			}

			rs.close();
			stmt.close();
			c.close();
			System.out.println("Opera��o realizada com sucesso!!!");
			
			return systemsIDS;
					
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		
		return null;
	}
	
//	public static void main (String [] args){
//		CS_SoSDBBroker cs_sos = new CS_SoSDBBroker();
//		cs_sos.droptable();
//		cs_sos.setUp();
//		cs_sos.insert(1, 99);	
//		System.out.println("A tabela ser� destru�da!");
//		cs_sos.droptable();
//	}
}
