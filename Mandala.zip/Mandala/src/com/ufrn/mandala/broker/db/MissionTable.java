package com.ufrn.mandala.broker.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MissionTable {
	private Connection c;
	private Statement stmt;
	
	private String nameDB;
	
	
	public MissionTable(String nameDB) {
		this.nameDB = nameDB;
	}

	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");
			
			String sql = "CREATE TABLE MISSION " +
							"(IDMISSION 		 INTEGER PRIMARY KEY NOT NULL," +
							"DESCRIPTION 		 TEXT 			NOT NULL," +
							"IDSOS 			 	 INTEGER 		NOT NULL)";

			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Tabela criada com sucesso!!!");
	}

	public void insert(int idmission, String description, int idsos){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO MISSION (IDMISSION, DESCRIPTION, IDSOS) " +
						"VALUES ('"+idmission+"', '"+description+"', '"+idsos+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
	}
	
//	public void selectAllMission(){
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
//			System.out.println("Base de dados aberta com sucesso!!!");
//			c.setAutoCommit(false);
//			stmt = c.createStatement();
//			
//			
//			ResultSet rs = stmt.executeQuery("SELECT * FROM MISSION");
//			while (rs.next()){
//				int idmission = rs.getInt("idmission");
//				int idsos = rs.getInt("idsos");
//				String description = rs.getString("description");
//				
//				System.out.println("IDMISSION = " + idmission);
//				System.out.println("IDSOS = " + idsos);
//				System.out.println("DESCRIPTION = " + description);
//				System.out.println();
//			}
//			rs.close();			
//			stmt.close();
//			c.close();
//			
//		} catch ( Exception e ){
//			System.err.println(e.getClass().getName() + ": " +e.getMessage());
//			System.exit(0);
//		}
//		System.out.println("Opera��o realizada com sucesso!!!");		
//	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'MISSION' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public int getSoSID(int missionID) {
		
		int idsos = -1;
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			
			ResultSet rs = stmt.executeQuery("SELECT IDSOS FROM MISSION WHERE IDMISSION = ' " + missionID + " '");
			while (rs.next()){				
				idsos = rs.getInt("idsos");
				
				System.out.println("IDSOS = " + idsos);
				System.out.println();
			}
			rs.close();			
			stmt.close();
			c.close();
			System.out.println("Opera��o realizada com sucesso!!!");
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}	
		return idsos;
	}
	
//	public static void main(String[] args){
//		MissionDBBroker m = new MissionDBBroker();
//		m.droptable();
//		m.setUp();
//		m.insert("descri��o", 1);
//		m.selectAllMission();
//		System.out.println("A tabela ser� destru�da!");
//		m.droptable();
//	}
}
