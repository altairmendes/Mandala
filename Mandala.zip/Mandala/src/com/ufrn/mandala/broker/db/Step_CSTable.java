package com.ufrn.mandala.broker.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Step_CSTable {

	private Connection c;
	private Statement stmt;
	
	private String nameDB;	
	
	public Step_CSTable(String nameDB) {	
		this.nameDB = nameDB;
	}

	public void setUp() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			stmt = c.createStatement();
			String sql = "CREATE TABLE STEPSYSTEMS " +
						"(IDSTEPSYSTEM INTEGER PRIMARY KEY NOT NULL," +
						"IDMISSION INTEGER NOT NULL," +
						"IDSTEP INTEGER NOT NULL," +
						"IDSYSTEM INTEGER NOT NULL)";
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Tabela criada com sucesso!!!");
	}

	public void insert(int idSystemStep, int idMission, int idsteps, int idsystem) {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sql = "INSERT INTO STEPSYSTEMS (IDSTEPSYSTEM, IDMISSION, IDSTEP, IDSYSTEM) " +
			"VALUES ('" + idSystemStep + "','" + idMission + "','" + idsteps
					+ "','" + idsystem + "')";
			stmt.executeUpdate(sql);
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Registros criados com sucesso!!!");

	}
	
	public void insert(int idSystemStep, int idMission, String idsteps, String idsystem) {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sql = "INSERT INTO STEPSYSTEMS (IDSTEPSYSTEM, IDMISSION, IDSTEP, IDSYSTEM) " +
			"VALUES ('" + idSystemStep + "','" + idMission + "','" + idsteps
					+ "','" + idsystem + "')";
			stmt.executeUpdate(sql);
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Registros criados com sucesso!!!");

	}
	

	public boolean find(int idMission, String idStep, String idSystem) {
		boolean bool = false;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM STEPSYSTEMS WHERE IDMISSION = '" + idMission
					+ "' AND  IDSTEP = '" + idStep + "' AND IDSYSTEM =  '" + idSystem + "'");
			// last() -> true if the cursor is on a valid row; false if there are no rows in
			// the result set
			if (rs.next()) {
				if (rs.getInt(1) > 0) {
					bool = true;
				}
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		return bool;
	}

	public void droptable() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'STEPSYSTEMS' ";
			System.out.println("output : " + stmt.executeUpdate(sqlCommand));
			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int findStepOwner(int stepID) {
		int systemID = -1;
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT IDSYSTEM FROM STEPSYSTEMS WHERE IDSTEP = '" +
					stepID + "'");
			if (rs.next()) {
				systemID = rs.getInt("idsystem");				
			}
			rs.close();
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		return systemID;
	}
}
