package com.ufrn.mandala.broker.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SoSTable {
	private Connection c;
	private Statement stmt;
	
	private String nameDB;
		
	public SoSTable(String nameDB) {
		this.nameDB = nameDB;
	}

	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");
			
			String sql = "CREATE TABLE SOS " +
					"(IDSOS 			INTEGER PRIMARY KEY NOT NULL," +
					" NAME 				TEXT 	NOT NULL," +
					" AGENTADDRESS		TEXT 	NOT NULL," +		
					" DESCRIPTION		TEXT	NOT NULL)";

			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	public void insert(int idSos, String name, String agentAddress, String desc ){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO SOS (IDSOS, NAME, AGENTADDRESS, DESCRIPTION) " +
						"VALUES ('"+idSos+"', '"+name+"', '"+agentAddress+"', '"+desc+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
	}
	
//	public void select(String sosName){
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
//			System.out.println("Base de dados aberta com sucesso!!!");
//			c.setAutoCommit(false);
//			stmt = c.createStatement();
//			
//			ResultSet rs = stmt.executeQuery("SELECT * FROM SOS where name='"+sosName+"'");
//			while (rs.next()){
//				int idsos = rs.getInt("idsos");
//				String name = rs.getString("name");
//				String description = rs.getString("description");
//				System.out.println("IDSOS = " + idsos);
//				System.out.println("NAME = " + name);
//				System.out.println("DESCRIPTION = " + description);
//				System.out.println();
//			}
//			
//			rs.close();			
//			stmt.close();
//			c.close();
//			
//		} catch ( Exception e ){
//			System.err.println(e.getClass().getName() + ": " +e.getMessage());
//			System.exit(0);
//		}
//		System.out.println("Opera��o realizada com sucesso!!!");
//	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'SOS' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public String getAddressWSAgent(int sosID) {
		String agentAddress = null;
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT AGENTADDRESS FROM SOS where IDSOS='" + sosID + "'");
			while (rs.next()){				
				agentAddress = rs.getString("agentaddress");
				System.out.println("AGENTADDRESS = " + agentAddress);
				System.out.println();
			}
			
			rs.close();			
			stmt.close();
			c.close();
			System.out.println("Opera��o realizada com sucesso!!!");	
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		
		return agentAddress;
	}
	
//	public static void main(String [] args){
//		SoSDBBroker s = new SoSDBBroker();
//		s.droptable();
//		s.setUp();
//		s.insert("SoS way truck", "endere�o", "SoS que faz o trajeto do caminh�o de lixo");
//		s.select("SoS way truck");
//		System.out.println("A tabela ser� destru�da!");
//		s.droptable();
//	}
}