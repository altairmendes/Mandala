package com.ufrn.mandala.broker.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;

public class StepTable {
	private Connection c;
	private Statement stmt;
	
	private String nameDB;	
	
	public StepTable(String nameDB) {		
		this.nameDB = nameDB;
	}

	public void setUp(){
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
						
			stmt = c.createStatement();
			String sql = "CREATE TABLE STEP " +
							"(IDSTEP INTEGER PRIMARY KEY NOT NULL," +
							"TYPE 			TEXT		 NOT NULL," +
							"IDBPMN 		TEXT		 NOT NULL," +
							"DESCRIPTION 	TEXT 		 NOT NULL," +
							"INCOMING 		TEXT		 NOT NULL," +
							"OUTCOMING 		TEXT 		 NOT NULL," +
							"TASK 			TEXT 		 NOT NULL," +							
							"SCRIPT 		TEXT 		 NOT NULL," +
							"IDMISSION 		INTEGER		 NOT NULL)";
			
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		}catch(Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
	}
	
	public void insert(int idstep, String type, String idbpmn,  String description, String incoming, String outcoming, String task, String script, int idmission){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");			
			c.setAutoCommit(false);
			stmt = c.createStatement();
		
			
			String sql = "INSERT INTO STEP (IDSTEP, TYPE, IDBPMN, DESCRIPTION, INCOMING, OUTCOMING, TASK, SCRIPT, IDMISSION) " +
						"VALUES ('"+idstep+"','"+type+"','"+idbpmn+"','"+description+"', '"+incoming+"', '"+outcoming+"','"+task+"','"+script+"','"+idmission+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
	}
	
	
	public ArrayList<Step> selectAllStepsOfMission(int idmission){
		ArrayList<Step> steps = new ArrayList<Step>();
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();			
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM STEP WHERE IDMISSION = '" + idmission +"'" );
			while (rs.next()){
				
				int idStep = rs.getInt("idstep");
				String type = rs.getString("type");
				String idbpmn = rs.getString("idbpmn");
				String description = rs.getString("description");
				String incoming = rs.getString("incoming");
				String outcoming = rs.getString("outcoming");
				String task = rs.getString("task");

				if(type.contains("bpmn2:startEvent")){					
					Step step = new StartEventStep(type, idbpmn , description, outcoming);
					steps.add(step);
				}
				else if (type.contains("bpmn2:endEvent")){
					Step step = new EndEventStep(type, idbpmn, description, incoming);
					steps.add(step);
				}
				else if(type.contains("bpmn2:scriptTask")){
					Step step = new ScriptTaskStep(type, idbpmn, description, incoming, outcoming,task);
					steps.add(step);
				}
				else if (type.contains("bpmn2:sequenceMission")){
					Step step = new SequenceFlowStep(type, idbpmn, description, incoming, outcoming);
					steps.add(step);
				}
			}
			rs.close();			
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}		
		return steps;	
	}
	
	public void droptable(){	
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'STEP' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public Step findStepByIDBpmn(String idBpmn){
		Step step = null; 
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();			
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM STEP WHERE IDBPMN = '" + idBpmn +"'" );;
			if(rs.next()) {

				int id = rs.getInt("idstep");
				String idbpmn = rs.getString("idbpmn");
				String type = rs.getString("type");
				String description = rs.getString("description");
				String incoming = rs.getString("incoming");
				String outcoming = rs.getString("outcoming");
				String task = rs.getString("task");
			
				if(type.contains("bpmn2:startEvent")){					
					step = new StartEventStep(type, idbpmn , description, outcoming);					
				}
				else if (type.contains("bpmn2:endEvent")){
					step = new EndEventStep(type, idbpmn, description, incoming);					
				}
				else if(type.contains("bpmn2:scriptTask")){
					step = new ScriptTaskStep(type, idbpmn, description, incoming, outcoming,task);					
				}
				else if (type.contains("bpmn2:sequenceFlow")){
					step = new SequenceFlowStep(type, idbpmn, description, incoming, outcoming);
				}
				
				rs.close();			
				stmt.close();
				c.close();
			}								
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}		
		return step;	
	}

	
	public String findFirstStep(int idmission) {
		String result = "";
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();			
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM STEP WHERE IDMISSION = '" + idmission +"' AND TYPE = 'bpmn2:startEvent'");
			
			if(rs.next()) {	 
				result = rs.getString("outcoming");
			}
			
			rs.close();			
			stmt.close();
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ArrayList<Integer> findStepsIDofMission(int missionID) {
		
		ArrayList<Integer> result = null;
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Broker-" + nameDB + ".db");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();			
			
			ResultSet rs = stmt.executeQuery("SELECT IDSTEP FROM STEP WHERE IDMISSION = '" + missionID +"'");
			
			result = new ArrayList<>(); 
			
			while(rs.next()) {	 
				result.add(rs.getInt("idstep"));
			}
			
			rs.close();			
			stmt.close();
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
//	public static void main(String[] args) {
//		StepTable s = new StepTable();
//		s.droptable();
//		s.setUp();
//		s.insert("bpmn2:endEvent", "idbpmn", "description", "incoming", "outcoming", "task", "script" ,1);
//		s.insert("bpmn2:startEvent", "idbpmn", "description", "incoming", "outcoming", "sript", "task", 1);
//		ArrayList<Step> steps = s.selectAllStepsOfMission(1);
//		for (int i = 0; i < steps.size(); i ++ ){
//			System.out.println(steps.get(i).getName());
//		}
//		System.out.println(s.findFirstStep(1));
//	}
}
