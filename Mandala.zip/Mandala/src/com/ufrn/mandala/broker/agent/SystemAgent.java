
package com.ufrn.mandala.broker.agent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONObject;

import com.ufrn.mandala.broker.dao.BrokerDataBaseDAO;
import com.ufrn.mandala.broker.systemInterface.AbstractSystemInterface;
import com.ufrn.mandala.model.CSystem;
import com.ufrn.mandala.model.DataBaseBroker;
import com.ufrn.mandala.model.GlobalMission;
import com.ufrn.mandala.model.Parameters;
import com.ufrn.mandala.model.StepCs;
import com.ufrn.mandala.model.StepResult;
import com.ufrn.mandala.model.SystemInformations;
import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ExclusiveGatewayStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;

/**
 * @author stefano Agente do Broker
 */

public class SystemAgent extends Agent {

	private static final long serialVersionUID = 1L;
	private BrokerDataBaseDAO repository;
	private AbstractSystemInterface adapter;
	private String nameSystem;
	
	//criando a variável global
	public static String jsonGlobal = "";

	public static String getJsonGlobal() {
		return jsonGlobal;
	}

	protected void salvarBanco(DataBaseBroker database) {
		// CS_SOS VAZIO
		int idMission = database.getIdmission();
		int idsos = database.getIdSos();
		String desc = database.getDescription();
		String name = database.getName();
		String agentAddress = database.getAgentId();

		repository.inserirMission(idMission, desc, idsos);
		repository.inserirSoS(idsos, name, agentAddress, desc);

		for (int i = 0; i < database.getCsTable().size(); i++) {
			CSystem system = database.getCsTable().get(i);
			repository.inserirConstituentSystem(system.getIdsystem(), system.getAddress(), system.getNameSystem());
		}

		for (int i = 0; i < database.getCsSos().size(); i++) {
			repository.inserirCSSoS(idsos, database.getCsSos().get(i).getIdcsystem());
		}

		for (int i = 0; i < database.getStepCSTable().size(); i++) {
			StepCs stepcs = database.getStepCSTable().get(i);
			repository.inserirStepCS(stepcs.getIdstepSystem(), idMission, stepcs.getIdsteps(), stepcs.getIdsystem());
		}

		// Inserir Step
		repository.insertFlow(database.getSteps(), idMission);

	}

	/**
	 * Executa o passo do fluxo
	 * 
	 * @param par
	 *            paremetro com os dados para executrar
	 * @return próximo passo do fluxo após execução
	 */
	protected StepResult executeStep(Parameters par) {
		Step current = par.getCurrentStep();

		if (current instanceof StartEventStep) {
			return new StepResult(((StartEventStep) current).getOutgoing(), new JSONObject());
		}
		if (current instanceof ScriptTaskStep) {
			System.out.println("Agent " + nameSystem + " - Executing a Task " + current.getIdBpmn());
			System.out.println(((ScriptTaskStep) current).getScript());

			JSONObject json = adapter.execute(((ScriptTaskStep) current).getScript(), new JSONObject(par.getParameters()));
	
		//	jsonGlobal = jsonGlobal + json.toString() + "<<";
		jsonGlobal = jsonGlobal + json.toString();
			
			System.out.println("JSON a armazenar: "+json);
			System.out.println("JSON Global: "+jsonGlobal);

			

			return new StepResult(((ScriptTaskStep) current).getOutgoing(), json);
		}
		if (current instanceof ExclusiveGatewayStep) {
			System.out.println("Step incoming: " + ((ExclusiveGatewayStep) current).getIncoming());
			System.out.println("Step outgoing: " + ((ExclusiveGatewayStep) current).getOutgoing());
			System.out.println("Step direction: " + ((ExclusiveGatewayStep) current).getDirection());
			// TODO verificar a condição para retornar
			// if (){
			// return
			// }
		}
		if (current instanceof EndEventStep) {
			
			
		//	JSONObject retornoJson = new JSONObject();
			
		//	retornoJson.put("resultado", jsonGlobal);
			
			
			return new StepResult("end", new JSONObject());
		//	return new StepResult("end", retornoJson);
		}

		if (current instanceof SequenceFlowStep) {
			return new StepResult(((SequenceFlowStep) current).getTargetRef(), new JSONObject());
		}

		return new StepResult("end", new JSONObject());
	}

	/**
	 * @param stepName
	 *            nome do passo
	 * @param flow
	 *            fluxo
	 * @return
	 */
	protected Step findStep(String stepName, ArrayList<Step> flow) {
		for (int i = 0; i < flow.size(); i++) {
			if (stepName.equals(flow.get(i).getIdBpmn())) {
				return flow.get(i);
			}
		}
		return null;
	}

	/**
	 * setting up the agent
	 **/
	protected void setup() {

		// Receber parametros na criação do agente
		Object[] args = getArguments();
		this.adapter = (AbstractSystemInterface) args[0];
		this.repository = (BrokerDataBaseDAO) args[1];
		SystemInformations infos = (SystemInformations) args[2];
		this.nameSystem = infos.getSystemName();

		System.out.println("Agent " + nameSystem + " is ready!");

		// Enviar os dados do formulário para Manager
		ACLMessage msinfos = new ACLMessage(ACLMessage.PROPOSE);
		try {
			msinfos.setContentObject(infos);
		} catch (IOException e1) {
			System.out.println("Erro ao setar objeto na mensagem");
			e1.printStackTrace();
		}

		// TODO receber nome do agente do Manager
		String sosManagerAgentAdress = "Manager";

		msinfos.addReceiver(new AID(sosManagerAgentAdress, AID.ISLOCALNAME));

		send(msinfos);

		addBehaviour(new CyclicBehaviour(this) {

			private static final long serialVersionUID = 1L;

			public void action() {
				// get the message
				ACLMessage receivedMessage = myAgent.receive();

				// Check if the message is empty;
				if (receivedMessage != null) {

					// Check if is the manager's Message
					if (receivedMessage.getPerformative() == ACLMessage.REQUEST) {
						Parameters parReceiver = null;

						try {
							parReceiver = (Parameters) receivedMessage.getContentObject();
						} catch (Exception e) {
							e.printStackTrace();
						}

						if (parReceiver != null) {

							Step currentStep = parReceiver.getCurrentStep();
							StepResult result;
							
							if (currentStep == null) {
								// Primeiro passo
								String nameFirstStep = repository.findFirstStep(parReceiver.getMissionID());
								currentStep = repository.findStepByIDBpmn(nameFirstStep);
								parReceiver.setCurrentStep(currentStep);
								
								result = executeStep(parReceiver);
								String next = result.getNext();
								
								parReceiver.setCurrentStep(repository.findStepByIDBpmn(next));

							}
							JSONObject respostaUltimopasso = new JSONObject();
							
							// Se o passo for para ele
							if (repository.isStepSystemOwner(parReceiver.getMissionID(),
									parReceiver.getCurrentStep().getIdBpmn(), nameSystem)) {

								result = executeStep(parReceiver);
								System.out.println("Saida da Execucao: " + result.toString() + "Tamanho: " + result.getJson().length());
								String next = result.getNext();								
								
								//Se o json for diferente de vazio
								if(result.getJson().length() > 0 ) {									
									respostaUltimopasso = result.getJson();
									parReceiver.setResult(result.getJson().toString());
								}
								
								if (!next.equals("end")) {
									// Find next step
									Step nextStep = repository.findStepByIDBpmn(next);

									if (nextStep != null) {
										// Verificando se o proximo não é uma seta
										if (nextStep instanceof SequenceFlowStep) {
											nextStep = repository
													.findStepByIDBpmn(((SequenceFlowStep) nextStep).getTargetRef());
										}

										// ATUALIZAR PARAMETROS
										parReceiver.setCurrentStep(nextStep);
										
										JSONObject jsonpar = new JSONObject(parReceiver.getParameters());
										
										//PEGAR ESSE JSON ANTERIOR E ACUMULAR COM O DA EXECUÇÃO										
										Iterator<String> keys = respostaUltimopasso.keys();
										while (keys.hasNext()) {
											String key = keys.next();
											jsonpar.accumulate(key, respostaUltimopasso.get(key));
										}
										parReceiver.setParameters(jsonpar.toString());
										

										// Envia Mensagem
										ACLMessage msg1 = new ACLMessage(ACLMessage.REQUEST);
										try {

											msg1.setContentObject(parReceiver);

											// Buscar os AID dos sistemas no banco Loop para add todos

											ArrayList<String> addressAgents = repository
													.getAgentSystemsAID(parReceiver.getMissionID());
											for (int i = 0; i < addressAgents.size(); i++) {
												msg1.addReceiver(new AID(addressAgents.get(i), AID.ISLOCALNAME));
											}

											send(msg1);

										} catch (Exception e) {
											e.printStackTrace();
										}
									} else {
										System.out.println("ERRO AO ENCONTRAR PRÓXIMO PASSO!");
									}

								}
								
								else {
									//ENTRA SOMENTE SE FOR O ÚLTIMO PASSO

									// ENVIAR RESPOSTA PARA WEB SERVICE
									ACLMessage msg1 = new ACLMessage(ACLMessage.INFORM);

									try {
										System.out.println("SA-> RESULTADO: " + parReceiver.getResult());
										msg1.setContentObject(parReceiver);

										// BUSCAR AID DO WS NO BANCO - Passar ID da missão
										String webServiceAgentAddress = repository
												.getWebServiceAdress(parReceiver.getMissionID());

										msg1.addReceiver(new AID(webServiceAgentAddress, AID.ISLOCALNAME));

										send(msg1);
									} catch (Exception e) {
										e.printStackTrace();
									}

								}
							}
						}
					}
					// RECEBE DADOS DE UMA NOVO SOS
					else if (receivedMessage.getPerformative() == ACLMessage.PROPAGATE) {
						try {
							// Inserir dados no Banco
							DataBaseBroker database = (DataBaseBroker) receivedMessage.getContentObject();

							salvarBanco(database);

							ACLMessage msg1 = receivedMessage.createReply();
							msg1.setContent("Recebi");
							send(msg1);

						} catch (UnreadableException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} else {
					block();
				}
			}
		});
	}
}