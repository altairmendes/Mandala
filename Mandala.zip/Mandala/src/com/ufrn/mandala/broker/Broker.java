package com.ufrn.mandala.broker;

import java.awt.EventQueue;
import java.util.Observable;
import java.util.Observer;

import com.ufrn.mandala.broker.dao.BrokerDataBaseDAO;
import com.ufrn.mandala.broker.form.Form;
import com.ufrn.mandala.broker.form.Form.Notifier;
import com.ufrn.mandala.broker.systemInterface.AbstractSystemInterface;
import com.ufrn.mandala.model.SystemInformations;

import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

/**
 * @author stefano
 *
 */

public class Broker {	
	
	private BrokerDataBaseDAO dao;
	private AbstractSystemInterface systemInterface;
	private ContainerController myContainer;
	private AgentController agent;
	private Obser observer = new Obser();
	private Form frame = new Form(observer);
	private SystemInformations infos;
	
	
	/**
	 * Padrão observer para enviar os dados do formulário para SoSManager
	 *
	 */
	public class Obser implements Observer {
	    public Obser() {
	    }

	    public void update(Observable observed, Object arg) {
	        if (observed instanceof Notifier) {
	            if (arg instanceof SystemInformations) {
	            	System.out.println("Recebi dados do form!");
	                infos = (SystemInformations) arg;
	                frame.setVisible(false);
	            }
	        }
	    }
	}
	
	
	
	/**
	 * Construtor da classe após receber dados do formulario
	 * Cria o agente e BD do Broker
	 * 
	 * @param myContainer  		Container JADE
	 * @param nameDB   			Nome do banco
	 * @param systemInterface	Interface do sistema
	 */
	public Broker( ContainerController myContainer, String nameDB, AbstractSystemInterface systemInterface) {
				
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		while(infos == null) {
			System.out.println("Esperando Form...");
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		this.dao = new BrokerDataBaseDAO(nameDB);
		this.systemInterface = systemInterface;
		
		this.myContainer = myContainer; 
		try {
			this.agent = myContainer.createNewAgent(infos.getAgentAddress(), "com.ufrn.mandala.broker.agent.SystemAgent", new Object[] {systemInterface, dao, infos });
			agent.start();
		} catch (StaleProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

//	public static void main(String[] args) {		
//		
//	}

}
