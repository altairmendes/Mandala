package com.ufrn.mandala.broker.dao;

import java.util.ArrayList;

import com.ufrn.mandala.broker.db.CS_SoSTable;
import com.ufrn.mandala.broker.db.ConstituentSystemTable;
import com.ufrn.mandala.broker.db.MissionTable;
import com.ufrn.mandala.broker.db.SoSTable;
import com.ufrn.mandala.broker.db.StepTable;
import com.ufrn.mandala.broker.db.Step_CSTable;
import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ExclusiveGatewayStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;

/**
 * @author stefano
 * Classe responsável pela comunicação com os BD
 */

public class BrokerDataBaseDAO {
	private CS_SoSTable csSosDBBroker;
	private ConstituentSystemTable csystemDBBroker;
	private MissionTable missionDBBroker;
	private SoSTable sosDBBroker;
	private StepTable stepDBBroker;
	private Step_CSTable stepCSDBBroker;

	/**
	 * Construtor dos bancos
	 * @param nameDB 	nome para o BD
	 */
	public BrokerDataBaseDAO(String nameDB) {
		
		csSosDBBroker = new CS_SoSTable(nameDB);
		csystemDBBroker = new ConstituentSystemTable(nameDB);
		missionDBBroker = new MissionTable(nameDB);
		sosDBBroker = new SoSTable(nameDB);
		stepDBBroker = new StepTable(nameDB);
		stepCSDBBroker = new Step_CSTable(nameDB);

		csSosDBBroker.droptable();
		csSosDBBroker.setUp();

		csystemDBBroker.droptable();
		csystemDBBroker.setUp();

		missionDBBroker.droptable();
		missionDBBroker.setUp();

		sosDBBroker.droptable();
		sosDBBroker.setUp();

		stepDBBroker.droptable();
		stepDBBroker.setUp();
		
		stepCSDBBroker.droptable();
		stepCSDBBroker.setUp();
	}
	
	/**
	 * Verifica se sistema executa tarefa
	 * 
	 * @param idMission
	 * @param idStep
	 * @param idSystem
	 * @return true: passo realizado pelo sistema
	 * @return false: passo não realizado pelo sistema
	 */
	public boolean isStepSystemOwner(int idMission, String idStep, String idSystem) {
		return stepCSDBBroker.find(idMission, idStep, idSystem);
	}
	
	/**
	 * Retorna ID do passo 
	 * @param idBpmn
	 * @return ID do passo do paremetro
	 */
	public Step findStepByIDBpmn(String idBpmn) {
		return stepDBBroker.findStepByIDBpmn(idBpmn);
	}

	/**
	 * @param missionID 
	 * @return ArrayList<String> dos passos da missão
	 */
	public ArrayList<String> getAgentSystemsAID(int missionID) {

		ArrayList<Integer> systemsIDs = findSystemsOfSoS(findSoSID(missionID));

		if (systemsIDs != null) {
			ArrayList<String> addressAgents = new ArrayList<>();

			for (int i = 0; i < systemsIDs.size(); i++) {
				addressAgents.add(getSystemAgentAddress(systemsIDs.get(i)));
			}
			return addressAgents;
		}
		return null;
	}


	public String getWebServiceAdress(int missionID) {
		return findAddressWSAgent(findSoSID(missionID));
	}

	private String findAddressWSAgent(int sosID) {
		return sosDBBroker.getAddressWSAgent(sosID);
	}

	private int findSoSID(int missionID) {
		return missionDBBroker.getSoSID(missionID);
	}

	private ArrayList<Integer> findSystemsOfSoS(int sosID) {
		return csSosDBBroker.getConstituentSistems(sosID);
	}

	private String getSystemAgentAddress(int systemID) {
		return csystemDBBroker.getAgentAddress(systemID);
	}

	/**
	 * Inserir novo Fluxo
	 * 
	 * @param flow
	 * @param idmission
	 */
	public void insertFlow( ArrayList<Step> flow, int idmission) {
		for (int i = 0; i < flow.size(); i++) {
			Step s = flow.get(i);

			// parâmetros : (String type, String idbpmn, String description, String
			// incoming, String outcoming, String task, String script, int idmission)

			// TODO VER TASK

			if (s instanceof StartEventStep) {
				stepDBBroker.insert( s.getIdBd(), s.getStepType(), s.getIdBpmn(), s.getName(), "", ((StartEventStep) s).getOutgoing(),
						"", "", idmission);
			} else if (s instanceof EndEventStep) {
				stepDBBroker.insert(s.getIdBd(), s.getStepType(), s.getIdBpmn(), s.getName(), ((EndEventStep) s).getIncoming(), "",
						"", "", idmission);
			} else if (s instanceof ScriptTaskStep) {
				stepDBBroker.insert(s.getIdBd(), s.getStepType(), s.getIdBpmn(), s.getName(), ((ScriptTaskStep) s).getIncoming(),
						((ScriptTaskStep) s).getOutgoing(), ((ScriptTaskStep) s).getScript(), "", idmission);
			} else if (s instanceof SequenceFlowStep) {
				stepDBBroker.insert(s.getIdBd(), s.getStepType(), s.getIdBpmn(), s.getName(), ((SequenceFlowStep) s).getSourceRef(),
						((SequenceFlowStep) s).getTargetRef(), "", "", idmission);
			} else if (s instanceof ExclusiveGatewayStep) {

				// TODO implementar
				// stepdao.insert(s.getIdBd(), idstep, idtype, idbpmn, description, incoming, outcoming, task,
				// script, idmission);
			}
		}
	}
	
	
	public void inserirConstituentSystem(int idsystem, String address, String nameSystem) {
		//MAIS DE UM
		csystemDBBroker.insert(idsystem, address, nameSystem);
	}
	
	public void inserirSoS(int idSos, String name, String agentAddress, String desc) {
		sosDBBroker.insert(idSos, name, agentAddress, desc);
	}
	
	public void inserirCSSoS(int idsos, int idcsystem) {
		//Mais de um
		csSosDBBroker.insert(idsos, idcsystem);
	}
	
	public void inserirMission(int idMission, String description, int idsos ) {
		//UM POR VEZ
		missionDBBroker.insert(idMission,description, idsos);
	}
	
	public void inserirStepCS(int idstepSystem, int idMission, String idsteps, String idsystem) {
		//Mais de um
		stepCSDBBroker.insert(idstepSystem, idMission, idsteps, idsystem);
	}
	
	public String findFirstStep(int idMission) {
		return stepDBBroker.findFirstStep(idMission);
	}

	//TESTE
//	public static void main(String[] args) {
//		BrokerDataBaseDAO brokerBD = new BrokerDataBaseDAO("bancoBrokerTeste");
//
//		ParserXML parser = new ParserXML();
//
//		String pathBpmn;
//
//		pathBpmn = new File("./src/newDiagram_1.bpmn").getAbsolutePath();
//		brokerBD.insertFlow(parser.parseToStep(pathBpmn), 1);
//
//		Scanner entrada = new Scanner(System.in);
//		int op = entrada.nextInt();
//
//		while (op != 0) {
//			if (op == 1) {
//				String bpmn = entrada.next();
//				System.out.println(brokerBD.findStepByIDBpmn(bpmn));
//			} else if (op == 2) {
//
//			} else if (op == 3) {
//
//			}
//			op = entrada.nextInt();
//		}findFirstStep(int idmission)
//		
//
//	}
	
}
