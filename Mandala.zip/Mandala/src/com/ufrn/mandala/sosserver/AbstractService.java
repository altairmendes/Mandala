package com.ufrn.mandala.sosserver;

import java.io.Serializable;

import org.json.JSONObject;

import com.ufrn.mandala.model.Parameters;


import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.util.leap.Properties;
import jade.wrapper.ControllerException;
import jade.wrapper.StaleProxyException;
import jade.wrapper.gateway.JadeGateway;

abstract class AbstractService {
	private JSONObject retorno = new JSONObject();
	
	/**
	 * Método genérico para comunicação do WS com agente
	 * @see jade.wrapper.gateway.JadeGateway
	 * @param req
	 * @param dest
	 */
	protected JSONObject comunicate(String req, String dest, JSONObject parametros) {
		
		try {
			System.out.println("WS: Enviar Mensagem!");
			Properties jadeProfile = new Properties();
			jadeProfile.setProperty("port", "1099");		
	        
			//JadeGateway.init(null, jadeProfile);
			
			if (JadeGateway.isGatewayActive()) { 				
				
			JadeGateway.shutdown();
			
			//System.out.println("JADEGATEWAY: Matou a instância");

			
			}
			
			JadeGateway.init(null, jadeProfile); 	
		//	System.out.println("JADEGATEWAY: Iniciou após o init");
			
		
			JadeGateway.execute(new OneShotBehaviour() {
				private static final long serialVersionUID = 1L;

				public void action() {
					
					try {
						//System.out.println("JADEGATEWAY: dentro do try");

						//Envia requisição da tarefa
						ACLMessage message = new ACLMessage(ACLMessage.REQUEST);
						message.setContent(parametros.toString());						
						AID agenteSos = new AID(dest, AID.ISLOCALNAME);
						message.addReceiver(agenteSos);
						myAgent.send(message);
						System.out.println("WS: Mensagem Enviada!");
						
						ACLMessage receivedMessage = myAgent.receive();
						
						int i = 0;
						while(receivedMessage == null || i < 20) {
							Thread.sleep(500);
							receivedMessage = myAgent.receive();
							if(receivedMessage != null) {
								System.out.println("SoSServer: Recebi mensagem!");
								if(receivedMessage.getPerformative() == ACLMessage.INFORM) {
									System.out.println("WS: Dados Recebidos!");
									Parameters p = (Parameters) receivedMessage.getContentObject();
									System.out.println("TA -> RESULTADO: " + p.getResult());
									retorno = new JSONObject(p.getResult());
									//Enviar para Agente do SoS Server (WebServiceAgente)
								}
							}
							i++;
						}
						//JadeGateway.shutdown();
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});						
			
		} catch (StaleProxyException e1) {
			e1.printStackTrace();
		} catch (ControllerException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
		return retorno;
	}
	
}