package com.ufrn.mandala.sosserver.dao;

import java.util.ArrayList;

import com.ufrn.mandala.model.step.Step;
import com.ufrn.mandala.sosserver.db.*;

public class SoSServerDataBaseDAO {
	private ConstituentSystemTable systemDBSoS;	
	private MissionTable missionDBSoS;
	private CS_MissionTable cs_missionDBSoS;
	

	/**
	 * Construtor do Banco de Dados
	 * @param nameDB
	 */
	public SoSServerDataBaseDAO(String nameDB) {
		systemDBSoS = new ConstituentSystemTable(nameDB);		
		missionDBSoS = new MissionTable(nameDB);
		cs_missionDBSoS = new CS_MissionTable(nameDB);
		
		System.out.println("Sistemas");
		systemDBSoS.droptable();
		systemDBSoS.setUp();
		
		System.out.println("Missao");
		missionDBSoS.droptable();
		missionDBSoS.setUp();
		
		System.out.println("Sistemas-Missao");
		cs_missionDBSoS.droptable();
		cs_missionDBSoS.setUp();

	}

	/**
	 * Encontrar passo
	 * @param idMission
	 * @return passo encontrado
	 */
	public Step findFirstStep(int idMission) {
		return missionDBSoS.findFirstStep(idMission);
	}


	/**
	 * Encontrar os identificadores dos agentes dos sistemas da missão passada
	 * @param missionID
	 * @return Array com os identificadores dos sistemas da missão
	 */
	public ArrayList<String> getAgentSystemsAID(int missionID) {

		ArrayList<Integer> systemsIDs = findSystemsOfMission(missionID);

		if (systemsIDs != null) {
			ArrayList<String> addressAgents = new ArrayList<>();

			for (int i = 0; i < systemsIDs.size(); i++) {
				addressAgents.add(getSystemAgentAddress(systemsIDs.get(i)));
			}
			return addressAgents;
		}

		return null;
	}
	
	/**
	 * Encontrar os ids dos sistemas da missão passada
	 * @param missionID
	 * @return
	 */
	private ArrayList<Integer> findSystemsOfMission(int missionID) {		
		return cs_missionDBSoS.getAllSystemsOfMission(missionID);
	}
	
	/**
	 * Encontrar o id do agente do sistema da missão passada
	 * @param idSystem
	 * @return
	 */
	private String getSystemAgentAddress(int idSystem) {		
		return systemDBSoS.getAgentAddress(idSystem);
	}
	
	//Só para testar os métodos
	public MissionTable getMissionDBSoS() {
		return missionDBSoS;		
	}	
	
	public ConstituentSystemTable getSystemDBSoS() {
		return systemDBSoS;		
	}
	
	public CS_MissionTable getCs_missionDBSoS() {
		return cs_missionDBSoS;
	}
	
	//TESTE
//	public static void main(String[] args) {
//		SoSServerDataBaseDAO sosServerBD = new SoSServerDataBaseDAO("bancoSoSTeste");
//		sosServerBD.getSystemAgentAddress(1);
//		sosServerBD.getMissionDBSoS().insert("Mdescrption", "Type", "IDBPMN", "Description", "Incoming", "Outcoming", "Task", "Script");
//		sosServerBD.getSystemDBSoS().insert("Address","Nome1");
//				
//	 }
}
