package com.ufrn.mandala.sosserver.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;

public class MissionTable {
	private Connection c;
	private Statement stmt;
	
	private String nameDB;
		
	public MissionTable(String nameDB) {
		this.nameDB = nameDB;
	}

	public void setUp(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");
			
			String sql = "CREATE TABLE MISSION " +
							"(IDMISSION 		INTEGER PRIMARY KEY	AUTOINCREMENT NOT NULL," +
							"MDESCRIPTION 		TEXT 	NOT NULL," +
							
							// FIRST STEP DATA:
							"TYPE 			TEXT		 NOT NULL," +
							"IDBPMN 		TEXT		 NOT NULL," +
							"DESCRIPTION 	TEXT 		 NOT NULL," +
							"INCOMING 		TEXT		 NOT NULL," +
							"OUTCOMING 		TEXT 		 NOT NULL," +
							"TASK 			TEXT 		 NOT NULL," +							
							"SCRIPT 		TEXT 		 NOT NULL)";
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Tabela criada com sucesso!!!");
	}

	public void insert(String mDescription, String type, String idbpmn, String description, String incoming, String outcoming, String task, String script){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO MISSION (MDESCRIPTION, TYPE, IDBPMN, DESCRIPTION, INCOMING, OUTCOMING, TASK, SCRIPT)" +
						 "VALUES ('"+mDescription+"', '"+type+"','" +idbpmn+"', '"+description+"', '"+incoming+ "', '"+outcoming+"', '"+task+"', '"+script+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
	}
	
//	public void selectAllMission(){
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
//			System.out.println("Base de dados aberta com sucesso!!!");
//			c.setAutoCommit(false);
//			stmt = c.createStatement();
//			
//			
//			ResultSet rs = stmt.executeQuery("SELECT * FROM MISSION");
//			while (rs.next()){
//				int id = rs.getInt("idmission");
//				int idsos = rs.getInt("idsos");
//				String description = rs.getString("description");
//				
//				System.out.println("IDMISSION = " + id);
//				System.out.println("IDSOS = " + idsos);
//				System.out.println("DESCRIPTION = " + description);
//				System.out.println();
//			}
//			rs.close();			
//			stmt.close();
//			c.close();
//			
//		} catch ( Exception e ){
//			System.err.println(e.getClass().getName() + ": " +e.getMessage());
//			System.exit(0);
//		}
//		System.out.println("Opera��o realizada com sucesso!!!");		
//	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'MISSION' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public Step findFirstStep(int idMission) {
		Step step = null; 
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			
			c.setAutoCommit(false);
			stmt = c.createStatement();			
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM STEP WHERE IDMISSION = '" + idMission +"'" );;
			if(rs.next()) {

				String idbpmn = rs.getString("idbpmn");
				String type = rs.getString("type");
				String description = rs.getString("description");
				String incoming = rs.getString("incoming");
				String outcoming = rs.getString("outcoming");
				String task = rs.getString("task");
			
				if(type.contains("bpmn2:startEvent")){					
					step = new StartEventStep(type, idbpmn , description, outcoming);					
				}
				else if (type.contains("bpmn2:endEvent")){
					step = new EndEventStep(type, idbpmn, description, incoming);					
				}
				else if(type.contains("bpmn2:scriptTask")){
					step = new ScriptTaskStep(type, idbpmn, description, incoming, outcoming,task);					
				}
				else if (type.contains("bpmn2:sequenceFlow")){
					step = new SequenceFlowStep(type, idbpmn, description, incoming, outcoming);
				}
				
				rs.close();			
				stmt.close();
				c.close();
			}								
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());
			System.exit(0);
		}		
		return step;	
	}
	
//	public static void main(String[] args){
//		MissionDBSoS m = new MissionDBSoS();
//		m.droptable();
//		m.setUp();
//		m.insert("descri��o", 1);
//		m.selectAllMission();
//		System.out.println("A tabela será  destruída!");
//		m.droptable();
//	}
}
