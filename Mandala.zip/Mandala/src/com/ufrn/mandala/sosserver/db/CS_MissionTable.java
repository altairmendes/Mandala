package com.ufrn.mandala.sosserver.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CS_MissionTable {
	private Connection c;
	private Statement stmt;
	
	private String nameDB;
	
	public CS_MissionTable(String nameDB) {
		this.nameDB = nameDB;
	}	
	
	public void setUp(){	
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = "CREATE TABLE CS_MISSION " +
							"(IDMISSION 	INTERGER 	NOT NULL," +
							"IDCSYSTEM INTERGER	NOT NULL)";	
						
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
			
		} catch ( Exception e ){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());		
		}
		System.out.println("Tabela criada com sucesso!!!");
	}
	
	
	public void insert(int idMission, int idcsystem){
		try{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");								
			System.out.println("Base de dados aberta com sucesso!!!");			
			c.setAutoCommit(false);
			stmt = c.createStatement();
			
			String sql = "INSERT INTO CS_MISSION (IDMISSION, IDCSYSTEM) " +
						"VALUES ('"+idMission+"', '"+idcsystem+"')";
			stmt.executeUpdate(sql);
			
			stmt.close();
			c.commit();
			c.close();
			
		}catch( Exception e){
			System.err.println(e.getClass().getName() + ": " +e.getMessage());	
		}
		System.out.println("Dados inseridos!!!");
	}
	
	public void droptable(){
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			c.setAutoCommit(false);
			
			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'CS_MISSION' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();     
			
			c.close();			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public ArrayList<Integer> getAllSystemsOfMission(int missionID) {

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT IDCSYSTEM FROM CS_MISSION where IDMISSION ='" + missionID + "'");
			ArrayList<Integer> systemsIDS = new ArrayList<>();
			
			while (rs.next()) {
				int idcsystem = rs.getInt("idcsystem");
				systemsIDS.add(idcsystem);
			}

			rs.close();
			stmt.close();
			c.close();
			System.out.println("Opera��o realizada com sucesso!!!");
			
			return systemsIDS;
					
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		
		return null;
	}

	
	
	

}
