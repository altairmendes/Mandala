package com.ufrn.mandala.sosserver.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConstituentSystemTable {
	private Connection c;
	private Statement stmt;

	private String nameDB;

	public ConstituentSystemTable(String nameDB) {
		this.nameDB = nameDB;
	}

	public void setUp() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			stmt = c.createStatement();
			System.out.println("Base de dados aberta com sucesso!!!");

			String sql = 	" CREATE TABLE CSYSTEM " + 
							" (IDCSYSTEM INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
							" NAMESYSTEM TEXT NOT NULL, " + 
							" ADDRESS TEXT NOT NULL)";

			stmt.executeUpdate(sql);
			stmt.close();
			c.close();

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Tabela criada com sucesso!!!");
	}

	public void insert(String address, String nameSystem) {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");

			c.setAutoCommit(false);
			stmt = c.createStatement();

			String sql = "INSERT INTO CSYSTEM (ADDRESS, NAMESYSTEM) " + "VALUES ('" + address + "', '" + nameSystem + "' )";
			stmt.executeUpdate(sql);

			stmt.close();
			c.commit();
			c.close();

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Registros criados com sucesso!!!");
	}

//	public void select(String csAddress) {
//		try {
//			Class.forName("org.sqlite.JDBC");
//			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
//			System.out.println("Base de dados aberta com sucesso!!!");
//			c.setAutoCommit(false);
//			stmt = c.createStatement();
//
//			ResultSet rs = stmt.executeQuery("SELECT * FROM CSYSTEM where address='" + csAddress + "'");
//			while (rs.next()) {
//				int idcsystem = rs.getInt("idcsystem");
//				String address = rs.getString("address");
//				System.out.println("IDCSYSTEM = " + idcsystem);
//				System.out.println("ADDRESS = " + address);
//				System.out.println();
//			}
//
//			rs.close();
//			stmt.close();
//			c.close();
//		} catch (Exception e) {
//			System.err.println(e.getClass().getName() + ": " + e.getMessage());
//			System.exit(0);
//		}
//		System.out.println("Opera��o realizada com sucesso!!!");
//	}

	public void droptable() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			c.setAutoCommit(false);

			stmt = c.createStatement();
			String sqlCommand = "DROP TABLE IF EXISTS 'CSYSTEM' ";

			System.out.println("output : " + stmt.executeUpdate(sqlCommand));

			stmt.close();
			c.commit();

			c.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getAgentAddress(int systemID) {
		
		String address = "";
		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:SoSServer-" + nameDB + ".db");
			System.out.println("Base de dados aberta com sucesso!!!");
			c.setAutoCommit(false);
			stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT ADDRESS FROM CSYSTEM where IDCSYSTEM ='" + systemID + "'");
					
			while (rs.next()) {
				address = rs.getString("address");
				System.out.println("ADDRESS = " + address);
				System.out.println();
			}

			rs.close();
			stmt.close();
			c.close();		
			
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Operção realizada com sucesso!!!");
		
		return address;
	}

	// public static void main(String [] agrs){
	// CSystemDBSoSServer cs = new CSystemDBSoSServer();
	// cs.droptable();
	// cs.setUp();
	// cs.insert("end123");
	// cs.select("end123");
	// System.out.println("A tabela ser� destru�da!");
	// cs.droptable();
	// }
}
