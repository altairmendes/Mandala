package com.ufrn.mandala.sosserver;

import com.ufrn.mandala.sosserver.dao.SoSServerDataBaseDAO;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

/**
 * @author stefano
 *
 */
public class SetUpWS {
	
	private static SetUpWS uniqueInstance;
	
	/**
	 * Inicialização do WS
	 * @throws StaleProxyException
	 */
	private SetUpWS() throws StaleProxyException {
		
		Runtime myRuntime = Runtime.instance();
        
        // Creation of a new main container                
        Profile myProfile = new ProfileImpl();
        myProfile.setParameter(Profile.MAIN_HOST, "localhost");
        myProfile.setParameter(Profile.MAIN_PORT, "1099");
        
        ContainerController myContainer = myRuntime.createAgentContainer(myProfile);
        
        try {
        	//PASSAR O NOME DO WS
        	
        	//String name = "Resposta";
        	String name = "Chamado";
        	
        	//PASSAR O NOME DA CLASSE CRIADA
       // 	AbstractService webService = new MeuServicoWS();
        
         	//AbstractService webService = new RespostaWS();
        	AbstractService webService = new ChamadoWS();
            
        	
        	SoSServerDataBaseDAO dao = new SoSServerDataBaseDAO(name);
        	SoSServer server = new SoSServer(myContainer, webService, dao, name);
        	    		
        } catch(Exception e) {
            e.printStackTrace();
        }	
	}

	/**
	 * Padrão Singleton
	 * @return
	 * @throws StaleProxyException
	 */
	public static synchronized SetUpWS getInstance() throws StaleProxyException {
		if (uniqueInstance == null){
			uniqueInstance = new SetUpWS();
		}

		return uniqueInstance;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			SetUpWS setup = SetUpWS.getInstance();
		} catch (StaleProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
