package com.ufrn.mandala.sosserver;

import com.ufrn.mandala.sosserver.dao.SoSServerDataBaseDAO;

import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

/**
 * Classe agregadora dos elementos do SoSSERVER
 *
 */
public class SoSServer{ 
	ContainerController ct;
	AbstractService service;
	SoSServerDataBaseDAO dao;
	//Adicionar FTP
	
	/**
	 * @param ct
	 * @param service
	 * @param dao
	 * @param sosName
	 */
	public SoSServer(ContainerController ct, AbstractService service, SoSServerDataBaseDAO dao, String sosName){
		this.ct = ct;
		this.service = service;
		this.dao = dao;
		
		try {
			AgentController MeuAgente = ct.createNewAgent(sosName, "com.ufrn.mandala.sosserver.WebServiceAgent", new Object[] {dao}  );
			MeuAgente.start();
		} catch (StaleProxyException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 */
	public void publicar(){
		
	}
}
