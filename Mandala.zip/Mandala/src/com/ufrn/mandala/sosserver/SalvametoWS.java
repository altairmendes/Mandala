package com.ufrn.mandala.sosserver;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.json.JSONObject;

import com.ufrn.mandala.broker.systemInterface.AmbulanciaSystemInterfaceOLD;
import com.ufrn.mandala.broker.systemInterface.HospitalSystemInterfaceOLD;

public class SalvametoWS extends AbstractService {

	//http://localhost:8080/Mandala/rest/servicoWS//socorrointeligente/{cep1}
	@GET
	@Path("/socorrointeligente/{cep1}")
	public JSONObject socorroInteligente() {
		return comunicate("salvamentointeligente", "nomeAgente", new JSONObject());
	}
	
	
//  private String aberturadeChamado (int cepChamado) {
//		
//		ArrayList <String> listaCep = new ArrayList();
//		
//		listaCep = new HospitalSystemInterface().execute("/listar/comleitos",null);
//		
//		int cepMelhorHospital = CalcularmelhorHospital (cep,listaCep);
//		
//		return new AmbulanciaSystemInterface().execute("/chamado/cadastrar", cepChamado, ceoMelhorHospital)
//		
//		
//		return "";
//	}
	
}
