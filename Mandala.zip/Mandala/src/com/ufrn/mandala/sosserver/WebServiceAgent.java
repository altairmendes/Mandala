package com.ufrn.mandala.sosserver;

import java.util.ArrayList;

import org.json.JSONObject;

import com.ufrn.mandala.model.Parameters;
import com.ufrn.mandala.sosserver.dao.SoSServerDataBaseDAO;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;

public class WebServiceAgent extends Agent {

	private static final long serialVersionUID = 1L;
	private SoSServerDataBaseDAO repository;
	private int mission = 1;

	/**
	 * Agente do SoS SeRVER
	 **/
	protected void setup() {
		// Receber parametros na criação do agente
		Object[] args = getArguments();
		this.repository = (SoSServerDataBaseDAO) args[0];

		System.out.println("SET UP AGENTE SOS");
		// Linkar endereço dos agentes do sistema
		System.out.println("Agente do : " + this.getLocalName() + " está pronto!");

		addBehaviour(new CyclicBehaviour(this) {

			private static final long serialVersionUID = 1L;

			public void action() {

				ACLMessage receivedMessage = myAgent.receive();

				if (receivedMessage != null) {
					System.out.println("WSAgent: recebeu mensagem!");

					if (receivedMessage.getPerformative() == ACLMessage.REQUEST) {

						try {
							String message =  receivedMessage.getContent();

							if (message != null) {

								// Enviar mensagem com a requisição
								Parameters parReceiver = new Parameters(receivedMessage, null, mission, message);

								ACLMessage msg1 = new ACLMessage(ACLMessage.REQUEST);
								try {

									msg1.setContentObject(parReceiver);
									
									// TODO Buscar os sistema da missão
									// Buscar os AID dos sistemas no banco - Loop para add todos
//									ArrayList<String> addressAgents = repository.getAgentSystemsAID(parReceiver.getMissionID());
//									for (int i = 0; i < addressAgents.size(); i++) {
//										msg1.addReceiver(new AID(addressAgents.get(i), AID.ISLOCALNAME));
//									}
								//	String sistema = "respostaoi";//colocar o nome do agente do 1o passo
									
									String sistema = "hospital";
									
									System.out.println("WSAgent:firstAgent"+sistema);
									msg1.addReceiver(new AID(sistema, AID.ISLOCALNAME));
									
									send(msg1);

								} catch (Exception e) {
									e.printStackTrace();
								}

							}
						} catch (Exception e) {
							e.printStackTrace();
						}
				
					}else if(receivedMessage.getPerformative() == ACLMessage.INFORM) {
							
						try {
							Parameters p = (Parameters) receivedMessage.getContentObject();
							if ( p != null) {
								System.out.println("WSA -> RESULTADO: "+p.getResult());
								ACLMessage mensagem = p.getMessage().createReply();
								mensagem.setContentObject(p);
								mensagem.setPerformative(ACLMessage.INFORM);
								send(mensagem);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		});

	}

}
