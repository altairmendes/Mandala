package com.ufrn.mandala.sosserver;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.json.JSONObject;



/**
 * CLASSE A SER CRIADA PELO DESENVOLVEDOR DO SOS
 *
 */
@Path("/servicoWS")
public class MeuServicoWS extends AbstractService{

//http://localhost:8080/Mandala/rest/servicoWS/teste
	
	@GET
	@Path("/teste")
	@Produces("application/json")
	public String teste() {
		System.out.println("Olá mundo!");		
		return "Olá mundo!";
	}
	
	// http://localhost:8080/Mandala/rest/servicoWS/request
	/* (non-Javadoc)
	 * @see com.ufrn.mandala.sosserver.AbstractService#request()
	 */
	@GET
	@Path("/request")
	@Produces("application/json")
	public JSONObject  request() {
		//TODO passar parametros
		return  comunicate("requisition", "webService1", new JSONObject() );
	}
	

}