package com.ufrn.mandala.sosserver;

import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import com.ufrn.mandala.broker.systemInterface.AmbulanciaSystemInterfaceOLD;
import com.ufrn.mandala.broker.systemInterface.HospitalSystemInterfaceOLD;

@Path("/respostaWS")
public class RespostaWS extends AbstractService {

	//http://localhost:8080/Mandala/rest/servicoWS//socorrointeligente/{cep1}
	//http://localhost:8080/Mandala/rest/respostaWS/SOSresposta
	@GET
	@Path("/SOSresposta")
	@Produces("application/json")
	public JSONObject respostaInteligente() {
		System.out.println("RespostaWS");
		return comunicate("respostaInteligente", "Resposta", new JSONObject());
		//parâmetro 2 é o nome do agente do sosserver, definido
		//em setupws. Nom BPMN deve ter o mesmo nome.
	}
	
	@GET
	@Path("/teste")
	@Produces("application/json")
	public String teste() {
		System.out.println("Olá mundo!");		
		return "Olá mundo!";
	}
	
	@GET
	@Produces("text/html")
	public Response getStartingPage() {
		String output = "<h1>Mandala OK!!!<h1>" + new Date().toString() + "<br>";
		return Response.status(200).entity(output).build();
	}
	
	
//	@GET
//	@Path("/SOS")
//	@Produces("application/json")
//	public JSONObject resposta() {
//		//System.out.println("RespostaWS");
//		//return comunicate("respostaFinal", "Resposta", new JSONObject());
//		//parâmetro 2 é o nome do agente do sosserver, definido
//		//em setupws. Nom BPMN deve ter o mesmo nome.
//		
//	}
	
	
//  private String aberturadeChamado (int cepChamado) {
//		
//		ArrayList <String> listaCep = new ArrayList();
//		
//		listaCep = new HospitalSystemInterface().execute("/listar/comleitos",null);
//		
//		int cepMelhorHospital = CalcularmelhorHospital (cep,listaCep);
//		
//		return new AmbulanciaSystemInterface().execute("/chamado/cadastrar", cepChamado, ceoMelhorHospital)
//		
//		
//		return "";
//	}
	
}
