package com.ufrn.mandala.model;
import java.io.Serializable;
import java.util.ArrayList;

public class SystemInformations implements Serializable{
	

	private static final long serialVersionUID = 1L;
	private int id;
	private String systemName;	
	private String description;
	private String agentAddress;
	private String urlBase;
	private ArrayList<Function> functions = new ArrayList<Function>();
		
	public SystemInformations(String systemName, String description, String agentAddress, String urlBase) {
		super();
		this.systemName = systemName;
		this.description = description;
		this.agentAddress = agentAddress;
		this.urlBase = urlBase;
	}

	public SystemInformations(int id, String systemName, String description, String agentAddress, String urlBase) {
		super();
		this.id = id;
		this.systemName = systemName;
		this.description = description;
		this.agentAddress = agentAddress;
		this.urlBase = urlBase;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAgentAddress() {
		return agentAddress;
	}

	public void setAgentAddress(String agentAddress) {
		this.agentAddress = agentAddress;
	}

	public String getUrlBase() {
		return urlBase;
	}

	public void setUrlBase(String urlBase) {
		this.urlBase = urlBase;
	}

	public ArrayList<Function> getFunctions() {
		return functions;
	}

	public void setFunctions(ArrayList<Function> functions) {
		this.functions = functions;
	}

	public int getFunctionID(String name) {
		for(int i = 0; i < functions.size(); i ++) {			
			System.out.println(name + "-" + functions.get(i).getName());
			if (functions.get(i).getName().equals(name)){
				return i;
			}			
		}
		return -1;
	}

	public int newFunction(String name,String path, String type) {
		functions.add(new Function(name, path, type));		
		return getFunctionID(name);
	}
	
	protected String printFunctions() {
		String data = "";
		for (int i = 0; i < functions.size(); i++) {
			data = data + "Path: " + functions.get(i).getLink() + "Name: "+ functions.get(i).getName() +
					"Method: " +functions.get(i).getMethod();
			for(int j = 0; j < functions.get(i).getInput().size(); j++ ) {
				data = data +"ParIN:" +functions.get(i).getInput().get(j).getName() + "Format: " +  functions.get(i).getInput().get(j).getFormat();
			}
			for(int k = 0; k < functions.get(i).getOutput().size(); k++ ) {
				data = data +"ParOUT:" +functions.get(i).getOutput().get(k).getName() + "Format: " +  functions.get(i).getOutput().get(k).getFormat();
			}
			
		}
		return data;
	}

	public String print() {
		String data = "Nome:" + systemName + " Descrição:" + description + 
				" AgentInfo: " + agentAddress + " Url:" + urlBase +
				printFunctions();		
		return data;
	}
}