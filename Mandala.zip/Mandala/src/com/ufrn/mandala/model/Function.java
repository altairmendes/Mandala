package com.ufrn.mandala.model;

import java.io.Serializable;
import java.util.ArrayList;


public class Function  implements Serializable{
		
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String path;
	private String type;
	private ArrayList<Parameter> input = new ArrayList<Parameter>(); //Se for post, passar na url na ordem do array
	private ArrayList<Parameter> output = new ArrayList<Parameter>();
	
	public static class Parameter implements Serializable{
	
		private static final long serialVersionUID = 1L;
		private String name;
		private String format; //tipo do dado TODO enumeração
		
		public Parameter(String name, String format) {
			super();
			this.name = name;
			this.format = format;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getFormat() {
			return format;
		}

		public void setFormat(String format) {
			this.format = format;
		}		
		
	};
	
	public Function(String path, String type, String name, ArrayList<Parameter> input, ArrayList<Parameter> output) {
		super();
		this.type = type;
		this.path = path;
		this.input = input;
		this.output = output;
		this.name = name;
	}
	public Function(String name,String path, String type) {
		super();
		this.name= name;
		this.type = type;
		this.path = path;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMethod() {
		return type;
	}

	public void setMethod(String type) {
		this.type = type;
	}

	public String getLink() {
		return path;
	}

	public void setLink(String path) {
		this.path = path;
	}

	public ArrayList<Parameter> getInput() {
		return input;
	}

	public void setInput(ArrayList<Parameter> input) {
		this.input = input;
	}

	public ArrayList<Parameter> getOutput() {
		return output;
	}

	public void setOutput(ArrayList<Parameter> output) {
		this.output = output;
	}
		
}
