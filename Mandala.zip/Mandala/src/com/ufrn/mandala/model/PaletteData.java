package com.ufrn.mandala.model;

import java.io.Serializable;
import java.util.ArrayList;

public class PaletteData implements Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<SystemInformations> systems;
	private ArrayList<Task> tasks;
	
	public PaletteData(ArrayList<SystemInformations> systems, ArrayList<Task> tasks) {
		super();
		this.systems = systems;
		this.tasks = tasks;
	}
	
	public ArrayList<SystemInformations> getSystems() {
		return systems;
	}
	
	public void setSystems(ArrayList<SystemInformations> systems) {
		this.systems = systems;
	}
	
	public ArrayList<Task> getTasks() {
		return tasks;
	}
	
	public void setTasks(ArrayList<Task> tasks) {
		this.tasks = tasks;
	}
	
}
