package com.ufrn.mandala.model;

import java.io.Serializable;

public class CSystemSos implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int idsos;
	private int idcsystem;
		
	public CSystemSos(int idsos, int idcsystem) {
		super();
		this.idsos = idsos;
		this.idcsystem = idcsystem;
	}
	public int getIdsos() {
		return idsos;
	}
	public void setIdsos(int idsos) {
		this.idsos = idsos;
	}
	public int getIdcsystem() {
		return idcsystem;
	}
	public void setIdcsystem(int idcsystem) {
		this.idcsystem = idcsystem;
	}
	
	

}
