package com.ufrn.mandala.model;

import java.io.Serializable;

public class StepCs implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int idstepSystem;
	private int idMission;
	private String idsteps; 
	private String idsystem;
	
	
	public StepCs(int idstep, int idMission, String idsteps, String idsystem) {
		super();
		this.idstepSystem = idstep;
		this.idMission = idMission;
		this.idsteps = idsteps;
		this.idsystem = idsystem;
	}
	
	public int getIdstepSystem() {
		return idstepSystem;
	}
	public void setIdstepSystem(int idstep) {
		this.idstepSystem = idstep;
	}
	public int getIdMission() {
		return idMission;
	}
	public void setIdMission(int idMission) {
		this.idMission = idMission;
	}
	public String getIdsteps() {
		return idsteps;
	}
	public void setIdsteps(String idsteps) {
		this.idsteps = idsteps;
	}
	public String getIdsystem() {
		return idsystem;
	}
	public void setIdsystem(String idsystem) {
		this.idsystem = idsystem;
	}
	
	
	
}
