package com.ufrn.mandala.model;

import java.io.Serializable;
import java.util.ArrayList;

import com.ufrn.mandala.model.step.Step;

public class DataBaseBroker implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int idmission;
	private int idSos;
	private String name;
	private String description;
	private String agentId;	
	
	private ArrayList<StepCs> stepCSTable;
	private ArrayList<CSystem> csTable;
	private ArrayList<Step> steps;
	private ArrayList<CSystemSos> csSos;
	
	
	
	public DataBaseBroker(int idmission, int idSos, String name, String description, String agentId,
			ArrayList<StepCs> stepCSTable, ArrayList<CSystem> csTable, ArrayList<Step> steps,
			ArrayList<CSystemSos> csSos) {
		super();
		this.idmission = idmission;
		this.idSos = idSos;
		this.name = name;
		this.description = description;
		this.agentId = agentId;
		this.stepCSTable = stepCSTable;
		this.csTable = csTable;
		this.steps = steps;
		this.csSos = csSos;
	}



	public int getIdmission() {
		return idmission;
	}



	public void setIdmission(int idmission) {
		this.idmission = idmission;
	}



	public int getIdSos() {
		return idSos;
	}



	public void setIdSos(int idSos) {
		this.idSos = idSos;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getAgentId() {
		return agentId;
	}



	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}



	public ArrayList<StepCs> getStepCSTable() {
		return stepCSTable;
	}



	public void setStepCSTable(ArrayList<StepCs> stepCSTable) {
		this.stepCSTable = stepCSTable;
	}



	public ArrayList<CSystem> getCsTable() {
		return csTable;
	}



	public void setCsTable(ArrayList<CSystem> csTable) {
		this.csTable = csTable;
	}



	public ArrayList<Step> getSteps() {
		return steps;
	}



	public void setSteps(ArrayList<Step> steps) {
		this.steps = steps;
	}



	public ArrayList<CSystemSos> getCsSos() {
		return csSos;
	}



	public void setCsSos(ArrayList<CSystemSos> csSos) {
		this.csSos = csSos;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
			
	
	
	
}
