package com.ufrn.mandala.model;

import java.io.Serializable;
import java.util.ArrayList;

import org.json.JSONObject;

import com.ufrn.mandala.model.step.Step;

import jade.lang.acl.ACLMessage;


public class Parameters implements Serializable {

	private static final long serialVersionUID = 1L;
	private Step currentStep;
	private ACLMessage message;
	private int missionID;
	private String parameters;
	private String result;
	
	public Parameters(ACLMessage m, Step current, int missionID, String parameters ){
		this.message = m;		
		this.currentStep = current;
		this.missionID = missionID;
		this.parameters = parameters;
		this.result = "";
	}
			
	public ACLMessage getMessage() {
		return message;
	}
			
	public Step getCurrentStep() {
		return currentStep;
	}

	public void setCurrentStep(Step currentStep) {
		this.currentStep = currentStep;
	}
	
	
	public int getMissionID() {
		return missionID;
	}

	public void setMissionID(int missionID) {
		this.missionID = missionID;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	

}