package com.ufrn.mandala.model;

import org.json.JSONObject;

import jersey.repackaged.com.google.common.base.MoreObjects.ToStringHelper;

public class StepResult {
	
	private String next;
	private JSONObject json;
	
	public StepResult(){
		this.next = "";
		this.json = new JSONObject();
	}
	
	public StepResult(String next, JSONObject json){
		this.next = next;
		this.json = json;
	}
	
	public void setNext(String next){
		this.next = next;
	}
	
	public void setJson(JSONObject json){
		this.json = json;
	}
	
	public String getNext(){
		return next;
	}
	
	public JSONObject getJson(){
		return json;
	}
	
	public String toString() {
		return "Proximo passo: " + next + "- Resposta: " + json.toString();
	}
	

}
