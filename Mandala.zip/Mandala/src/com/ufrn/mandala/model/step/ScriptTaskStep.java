package com.ufrn.mandala.model.step;

public class ScriptTaskStep extends Step {

	private static final long serialVersionUID = 1L;
	
	private String incoming;
	private String outgoing;
	private String script;
		
	public ScriptTaskStep(String type, String id, String name,
			String incoming, String outgoing, String script) {
		super(type, id, name);
		this.incoming = incoming;
		this.outgoing = outgoing;
		this.script = script;
	}
	
	public ScriptTaskStep(int idstep, String type, String id, String name,
			String incoming, String outgoing, String script) {
		super(type, id, name, idstep);
		this.incoming = incoming;
		this.outgoing = outgoing;
		this.script = script;
	}

	public String getIncoming() {
		return incoming;
	}

	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}

	public String getOutgoing() {
		return outgoing;
	}

	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}

	public String getScript() {
		return script;
	}

	public void setScript(String script) {
		this.script = script;
	}
	
}
