package com.ufrn.mandala.model.step;

import jade.util.leap.Serializable;

public abstract class Step implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String stepType;
	private String idbpmn;
	private String name;
	private int idbd;
	
	
	public Step(String type, String idbpmn, String name){
		stepType = type;
		this.idbpmn = idbpmn;
		this.name = name;
	}
	
	public Step(String type, String idbpmn, String name, int idbd){
		stepType = type;
		this.idbpmn = idbpmn;
		this.name = name;
		this.idbd = idbd;
	}
	
	public String getStepType() {
		return stepType;
	} 
	public void setStepType(String elementType) {
		this.stepType = elementType;
	}
	public String getIdBpmn() {
		return idbpmn;
	}
	public void setIdBpmn(String id) {
		this.idbpmn = id;
	}
	public int getIdBd() {
		return idbd;
	}
	public void setIdBd(int id) {
		this.idbd = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

