package com.ufrn.mandala.model.step;

public class ExclusiveGatewayStep extends Step {

	private static final long serialVersionUID = 1L;
	private String direction;
	private String incoming;
	private String outgoing;
	
	public ExclusiveGatewayStep(String type, String id, String name, String direction, String incoming, String outgoing) {
		super(type, id, name);
		this.setDirection(direction);
		this.setIncoming(incoming);
		this.setOutgoing(outgoing);
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getIncoming() {
		return incoming;
	}

	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}

	public String getOutgoing() {
		return outgoing;
	}

	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}
	
}
