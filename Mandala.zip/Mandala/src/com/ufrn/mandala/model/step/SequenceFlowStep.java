package com.ufrn.mandala.model.step;

public class SequenceFlowStep extends Step {
	
	private static final long serialVersionUID = 1L;
	
	private String sourceRef;
	private String targetRef;

	public SequenceFlowStep(String type, String id, String name, String source, String targuet) {
		super(type, id, name);
		this.setSourceRef(source);
		this.setTargetRef(targuet);
	}
	
	public SequenceFlowStep(int idstep, String type, String id, String name, String source, String targuet) {
		super(type, id, name, idstep);
		this.setSourceRef(source);
		this.setTargetRef(targuet);
	}

	public String getSourceRef() {
		return sourceRef;
	}

	public void setSourceRef(String sourceRef) {
		this.sourceRef = sourceRef;
	}

	public String getTargetRef() {
		return targetRef;
	}

	public void setTargetRef(String targetRef) {
		this.targetRef = targetRef;
	}	
}