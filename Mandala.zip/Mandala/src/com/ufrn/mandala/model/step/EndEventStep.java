package com.ufrn.mandala.model.step;

public class EndEventStep extends Step {

	private static final long serialVersionUID = 1L;
	private String incoming;
	
	public EndEventStep(String type, String id, String name, String incoming) {
		super(type, id, name);
		this.setIncoming(incoming);
	}
	
	public EndEventStep(int idstep, String type, String id, String name, String incoming) {
		super(type, id, name, idstep);
		this.setIncoming(incoming);
	}

	public String getIncoming() {
		return incoming;
	}

	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}

	
		
}
