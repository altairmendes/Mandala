package com.ufrn.mandala.model.step;

public class StartEventStep extends Step {
	
	private static final long serialVersionUID = 1L;
	
	private String outgoing;

	public StartEventStep(String type, String id, String name, String outgoing) {
		super(type, id, name);
		this.setOutgoing(outgoing);
	}

	public StartEventStep(int idb, String type, String id, String name, String outgoing) {
		super(type, id, name, idb);
		this.setOutgoing(outgoing);
	}

	public String getOutgoing() {
		return outgoing;
	}

	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}

}
