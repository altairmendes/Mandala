package com.ufrn.mandala.model;

import java.io.Serializable;

public class CSystem implements Serializable{
	private int idsystem;
	private String address;
	private String nameSystem;
	
	public CSystem(int idsystem, String address, String nameSystem) {
		super();
		this.idsystem = idsystem;
		this.address = address;
		this.nameSystem = nameSystem;
	}

	public int getIdsystem() {
		return idsystem;
	}

	public void setIdsystem(int idsystem) {
		this.idsystem = idsystem;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNameSystem() {
		return nameSystem;
	}

	public void setNameSystem(String nameSystem) {
		this.nameSystem = nameSystem;
	}
	
	
	
	
}
