package com.ufrn.mandala.model;

import java.io.Serializable;
import java.util.ArrayList;

import com.ufrn.mandala.model.step.Step;

/**
 * @author stefano
 *
 */
public class GlobalMission implements Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<Step> steps;
	private ArrayList<Pair> parseToSwinLane;
	private String name;
	private String desc;
		
	public GlobalMission(ArrayList<Step> steps, ArrayList<Pair> parseToSwinLane, String name, String desc) {
		super();
		this.steps = steps;
		this.parseToSwinLane = parseToSwinLane;
		this.name = name;
		this.desc = desc;
	}
	public ArrayList<Step> getSteps() {
		return steps;
	}
	public void setSteps(ArrayList<Step> steps) {
		this.steps = steps;
	}
	public ArrayList<Pair> getParseToSwinLane() {
		return parseToSwinLane;
	}
	public void setParseToSwinLane(ArrayList<Pair> parseToSwinLane) {
		this.parseToSwinLane = parseToSwinLane;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
	
}
