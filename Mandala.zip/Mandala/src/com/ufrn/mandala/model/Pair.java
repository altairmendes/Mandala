package com.ufrn.mandala.model;

import java.io.Serializable;

public class Pair implements Serializable{
	   private String first;//first member of pair
	   private String second;//second member of pair

	   public Pair(String first, String second){
	     this.first = first;
	     this.second = second;
	   }

	   public void setFirst(String first){
	    this.first = first;
	   }

	   public void setSecond(String second) {
	     this.second = second;
	   }

	   public String getFirst() {
	     return this.first;
	   }

	   public String getSecond() {
	     return this.second;
	   }
}