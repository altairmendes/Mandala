package com.ufrn.mandala.setup;

import com.ufrn.mandala.broker.Broker;
import com.ufrn.mandala.broker.systemInterface.AmbulanciaSystemInterfaceOLD;
import com.ufrn.mandala.broker.systemInterface.GeograficSystemInterfaceOLD;
import com.ufrn.mandala.broker.systemInterface.HospitalSystemInterfaceOLD;
import com.ufrn.mandala.broker.systemInterface.RespostaOISystemInterface;
import com.ufrn.mandala.broker.systemInterface.RespostaOKSystemInterface;
import com.ufrn.mandala.broker.systemInterface.RoutesSystemInterface;
import com.ufrn.mandala.soscomposer.Composer;
import com.ufrn.mandala.sosmanager.Manager;
import com.ufrn.mandala.sosmanager.dao.SoSManagerDataBaseDAO;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

public class SetUp {
	
	private static SetUp uniqueInstance;
	
	/**
	 * @throws StaleProxyException
	 * Criação do manager
	 * Criação do composer
	 * Criação dos agentes para os sistemas
	 */
	private SetUp() throws StaleProxyException {
		
		Runtime myRuntime = Runtime.instance();
        
        // Creation of a new main container                
        Profile myProfile = new ProfileImpl();
        myProfile.setParameter(Profile.MAIN_HOST, "localhost");
        myProfile.setParameter(Profile.MAIN_PORT, "1099");
        
        ContainerController myContainer = myRuntime.createAgentContainer(myProfile);
        
        try {   		  	
        	SoSManagerDataBaseDAO managerdao = new SoSManagerDataBaseDAO();
        	Manager manager = new Manager(myContainer, managerdao );
        	Composer composer = new Composer();
        	
        	//INSTANCIAR OS BROKERS DOS SISTEMAS
        	
        	
        	HospitalSystemInterfaceOLD hospitalInterface = new HospitalSystemInterfaceOLD();
        	Broker hospital = new Broker(myContainer, "DBHospital", hospitalInterface);
        	
        	GeograficSystemInterfaceOLD geograficInterface = new GeograficSystemInterfaceOLD();
        	Broker geografic = new Broker(myContainer, "DBgeografic", geograficInterface);
        	
        	AmbulanciaSystemInterfaceOLD ambulanciaInterface = new AmbulanciaSystemInterfaceOLD();
        	Broker ambulancia = new Broker(myContainer, "DBAmbulance", ambulanciaInterface);
        	  
        	
//        	RespostaOISystemInterface respostaoiInterface = new RespostaOISystemInterface();
//        	Broker respostaoi = new Broker(myContainer, "DBrespostaoi", respostaoiInterface);
//        	
//        	RespostaOKSystemInterface respostaokInterface = new RespostaOKSystemInterface();
//        	Broker respostaok = new Broker(myContainer, "DBrespostaok", respostaokInterface);
//        	
        	
        	Thread.sleep(10000);
        	composer.deploySoS();
    		
        } catch(Exception e) {
            e.printStackTrace();
        }	
	}
	
	//Padrão Singleton
	public static synchronized SetUp getInstance() throws StaleProxyException {
		if (uniqueInstance == null){
			uniqueInstance = new SetUp();
		}

		return uniqueInstance;
	}

	public static void main(String[] args) {
		try {
			SetUp setup = SetUp.getInstance();
		} catch (StaleProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
