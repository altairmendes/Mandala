package com.ufrn.mandala.soscomposer.parser;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ufrn.mandala.model.Pair;
import com.ufrn.mandala.model.step.EndEventStep;
import com.ufrn.mandala.model.step.ExclusiveGatewayStep;
import com.ufrn.mandala.model.step.ScriptTaskStep;
import com.ufrn.mandala.model.step.SequenceFlowStep;
import com.ufrn.mandala.model.step.StartEventStep;
import com.ufrn.mandala.model.step.Step;



public class ParserXML {

	/**
	 * Faz a tradução do arquivo bpmn dos passos para arraylist
	 * @param pathFile caminho do arquivo
	 * @return ArrayList com passos
	 */
	public ArrayList<Step> parseToStep(String pathFile){
		
		ArrayList<Step> stepList = new ArrayList<Step>();
		
		try {    
			File fXmlFile = new File(pathFile);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();
		
			NodeList startEventList = doc.getElementsByTagName("bpmn2:startEvent");
			
			NodeList endEventList = doc.getElementsByTagName("bpmn2:endEvent");
			
			NodeList scriptTaskList = doc.getElementsByTagName("bpmn2:scriptTask");
			
			NodeList sequenceFlowList = doc.getElementsByTagName("bpmn2:sequenceFlow");
			
			NodeList exclusiveGatewayList = doc.getElementsByTagName("bpmn2:exclusiveGateway");
									
			for (int temp = 0; temp < sequenceFlowList.getLength(); temp++) {
				
				Node nNode = sequenceFlowList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) nNode;
					
					
					SequenceFlowStep sequence = new SequenceFlowStep(nNode.getNodeName(), 
						eElement.getAttribute("id"),eElement.getAttribute("name"),
						eElement.getAttribute("sourceRef"),eElement.getAttribute("targetRef"));
					stepList.add(sequence);
				}
			}		
						
			for (int temp = 0; temp < startEventList.getLength(); temp++) {
		
				Node nNode = startEventList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
		
					Element eElement = (Element) nNode;
					StartEventStep startEvent = new StartEventStep(nNode.getNodeName(), eElement.getAttribute("id"),eElement.getAttribute("name"),eElement.getElementsByTagName("bpmn2:outgoing").item(0).getTextContent());
					stepList.add(startEvent);
				}
			}
			for (int temp = 0; temp < exclusiveGatewayList.getLength(); temp++) {
		
				Node nNode = exclusiveGatewayList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
		
					Element eElement = (Element) nNode;
					
					ExclusiveGatewayStep exclusiveGateway = new ExclusiveGatewayStep(nNode.getNodeName(),eElement.getAttribute("id"),eElement.getAttribute("name"), eElement.getAttribute("gatewayDirection"), eElement.getElementsByTagName("bpmn2:incoming").item(0).getTextContent(), eElement.getElementsByTagName("bpmn2:outgoing").item(0).getTextContent());
					stepList.add(exclusiveGateway);
				}
			}
		
			for (int temp = 0; temp < scriptTaskList.getLength(); temp++) {
		
				Node nNode = scriptTaskList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) nNode;
					
					ScriptTaskStep scriptTask = new ScriptTaskStep(nNode.getNodeName(), eElement.getAttribute("id"), eElement.getAttribute("name"),eElement.getElementsByTagName("bpmn2:incoming").item(0).getTextContent(), eElement.getElementsByTagName("bpmn2:outgoing").item(0).getTextContent(), eElement.getElementsByTagName("bpmn2:script").item(0).getTextContent());
					stepList.add(scriptTask);
				}
			}
		
			for (int temp = 0; temp < endEventList.getLength(); temp++) {
		
				Node nNode = endEventList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
		
					Element eElement = (Element) nNode;
		
					EndEventStep endEvent = new EndEventStep(nNode.getNodeName(),eElement.getAttribute("id"), eElement.getAttribute("name"),eElement.getElementsByTagName("bpmn2:incoming").item(0).getTextContent());
					stepList.add(endEvent);	
				}
			}
	    } catch (Exception e) {
		e.printStackTrace();
	    }
		System.out.println("Parser Feito com sucesso!");
		System.out.println(stepList);
		return stepList;
	}
	
	/**
	 * Faz a tradução do arquivo bpmn dos sistemas para arraylist
	 * @param pathFile
	 * @return ArrayList com pares sistemas-passos
	 */
	public ArrayList<Pair> parseToSwinLane(String pathFile){
		
		ArrayList<Pair> systemTaskList = new ArrayList<Pair>();
		
		try {    
			File fXmlFile = new File(pathFile);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();		
		
			NodeList laneList = doc.getElementsByTagName("bpmn2:lane");
			
			for (int temp = 0; temp < laneList.getLength(); temp++) {
				
				Node nNode = laneList.item(temp);
		
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
		
					Element eElement = (Element) nNode;
					
					NodeList taskList = eElement.getElementsByTagName("bpmn2:flowNodeRef");
					
					for (int temp1 = 0; temp1 < taskList.getLength(); temp1++) {
						
						Node node = taskList.item(temp1);
						
						if (node.getNodeType() == Node.ELEMENT_NODE) {					
							systemTaskList.add(new Pair(eElement.getAttribute("name"),node.getTextContent()));
						}
					}					
				}
			}								
			
	    } catch (Exception e) {
		e.printStackTrace();
	    }
		System.out.println("Parser Feito com sucesso!");
		return systemTaskList;
	}
	
	//TESTE
//	public static void main(String[] args) {
//		ParserXML p = new ParserXML();		
//		ArrayList<Pair<String, String>> list = p.parseToSwinLane("/home/stefano/workspace/SistemadeSistemas/src/pc.bpmn");
//		
//		for (int temp = 0; temp < list.size(); temp++) {
//			System.out.println(list.get(temp).getKey() + "     /     "+  list.get(temp).getValue() );
//			
//		}
////		ArrayList<Step> steps = p.parseToStep("/home/stefano/workspace/SistemadeSistemas/src/pc.bpmn");
////		for (int temp = 0; temp < steps.size(); temp++) {
////			System.out.println("IDBPMN: " + steps.get(temp).getIdBpmn() + " NAME: " + steps.get(temp).getName() + " TYPE: " + steps.get(temp).getStepType());
////		}		
//		
//	
//	}
	
}