package com.ufrn.mandala.soscomposer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

import com.ufrn.mandala.model.GlobalMission;
import com.ufrn.mandala.model.Pair;
import com.ufrn.mandala.model.PaletteData;
import com.ufrn.mandala.model.SystemInformations;
import com.ufrn.mandala.model.Task;
import com.ufrn.mandala.model.step.Step;
import com.ufrn.mandala.soscomposer.parser.ParserXML;

import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.util.leap.Properties;
import jade.wrapper.ControllerException;
import jade.wrapper.StaleProxyException;
import jade.wrapper.gateway.JadeGateway;

public class Composer {
	
	private Scanner s;


	/**
	 * Método principal: Chama os outros métodos
	 */
	public void deploySoS() {		
		atualizarPalette();
		System.out.println("Palette atualizado! \n Abra o editor para criar o SoS");
		
		System.out.println("Após criar a Missão Global, entre com o caminho do arquivo criado:");
		s = new Scanner(System.in);		
		String pathBpmn = s.nextLine();
		
		System.out.println("Entre com o nome para a Missão Global criada:");
		String name = s.nextLine();
		
		System.out.println("Entre com a descrição para a Missão Global criada:");
		String desc = s.nextLine();
		
		sendSoSToManager(pathBpmn, name, desc);
		System.out.println("Dados Enviados para Manager");
			
	}
		
	/**
	 * Solicita os dados ao mamager
	 * @see Composer.escreverArquivo 
	 */
	protected void atualizarPalette() {
		
		System.out.println("Atualizando Palette...");
		try {
			System.out.println("Composer: Enviar Mensagem!");
			Properties jadeProfile = new Properties();
			jadeProfile.setProperty("port", "1099");
			//jadeProfile.setProperty("container", true);			
	        
			JadeGateway.init(null, jadeProfile);
			JadeGateway.execute(new OneShotBehaviour() {
				private static final long serialVersionUID = 1L;

				public void action() {
					try {
						//Envia requisição das infos
						ACLMessage message = new ACLMessage(ACLMessage.INFORM);
						message.setContent("getData");
						AID agenteSos = new AID("Manager", AID.ISLOCALNAME);
						message.addReceiver(agenteSos);
						myAgent.send(message);
						System.out.println("Composer: Mensagem Enviada!");
						
						ACLMessage receivedMessage = myAgent.receive();
											
						while(receivedMessage == null) {
							receivedMessage = myAgent.receive();
							if(receivedMessage != null) {
								System.out.println("Composer: Recebi mensagem!");
								if(receivedMessage.getPerformative() == ACLMessage.INFORM) {
									System.out.println("Composer: Dados Recebidos!");
									PaletteData infos = (PaletteData) receivedMessage.getContentObject();
									escreverArquivo(infos.getSystems(), infos.getTasks());
								}
							}
						}
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});						
			
		} catch (StaleProxyException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ControllerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
	}
	
	/**
	 * Cria arquivo para configurar o palette
	 * @param systems  Array com os sistemas cadastrados no mandala
	 * @param tasks    Array com as tarefas cadastradas no mandala
	 */
	public void escreverArquivo(ArrayList<SystemInformations> systems, ArrayList<Task> tasks) {
		try {
			String path = new File("").getAbsolutePath();
			System.out.println(path);
			FileWriter fstream = new FileWriter(path + "/.bpmn2config/out.xml");
			BufferedWriter out = new BufferedWriter(fstream);
			String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
						 "<runtime id=\"org.eclipse.bpmn2.modeler.runtime.none\">\n" +
					     "<toolPalette id=\"org.bpmn2.modeler.toolpalette.my.full\" profile=\"Mandala\">\n" +
					     "<category id=\"org.bpmn2.modeler.toolpalette.default.categories\"/>\n" +
					     "<category id=\"org.bpmn2.modeler.toolpalette.my.systems\" name=\"Systems\">\n";
			
			for(int i = 0; i < systems.size() ; i++) {
				xml = xml + "<tool name=\"" + systems.get(i).getSystemName() + "\" description=\""+ systems.get(i).getDescription() + "\">\n" + 
	            "<object type=\" Lane [$name='"+systems.get(i).getSystemName()+"',$id='L"+systems.get(i).getId() +"']\"/>\n" + "</tool>";
			}	
			
			xml = xml + "</category>\n <category id=\"org.bpmn2.modeler.toolpalette.my.systemsTasks\" name=\"Systems Tasks\">";
			
			//INSERE AS TAREFAS
			for(int i = 0; i < tasks.size(); i ++) {
				xml = xml + "<tool name=\""+ tasks.get(i).getName() +"\" description=\""+ tasks.get(i).getType()+"\">"+
                "<object type=\"ScriptTask[$name='"+ tasks.get(i).getName() +"',$script='"+ "infos" +"']\"/>" + "</tool>";
			}
			
			xml = xml + "</category>\n </toolPalette> </runtime>";
			out.write(xml);
			out.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}	
	
	
	/**
	 * Enviar os dados de criação do SoS para o Manger
	 * @param pathBpmn
	 * @param description
	 */
	protected void sendSoSToManager(String pathBpmn, String name, String desc) {
//https://projetos.imd.ufrn.br/SmartMetropolis-MiddlewareGroup/interoperability/commit/5689c4ddfde87d9fa7cc17b1431931a26b86c912
		ParserXML parser = new ParserXML();
		final ArrayList<Step> steps = parser.parseToStep(pathBpmn);
		final ArrayList<Pair> parseToSwinLane = parser.parseToSwinLane(pathBpmn);
				
		try {
			System.out.println("Composer: Enviar Mensagem!");
			Properties jadeProfile = new Properties();
			//jadeProfile.setBooleanProperty("container", true);
			jadeProfile.setProperty("port", "1099");
	        	        
			JadeGateway.init(null, jadeProfile);
			JadeGateway.execute(new OneShotBehaviour() {
				private static final long serialVersionUID = 1L;

				public void action() {
					try {
						ACLMessage message = new ACLMessage(ACLMessage.INFORM);
						
						message.setContentObject(new GlobalMission(steps, parseToSwinLane, name, desc ));
						AID agenteSos = new AID("Manager", AID.ISLOCALNAME);
						message.addReceiver(agenteSos);
						myAgent.send(message);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});						
			System.out.println("Composer: Mensagem Enviada!");
		} catch (StaleProxyException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ControllerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
	}
		
	//TESTE
//	public static void main(String[] args) {
//		
//		Composer c = new Composer();
//		c.deploySoS();
//	}
}
