package br.com.dao;

import br.com.codigo.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DAO {
	
	
	
	public Connection conectarBD() throws ClassNotFoundException {
		Connection connection = null;  
			                
	        try {
				Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitais?autoReconnect=true&useSSL=false", "root", "a12762");
	            System.out.println("Base acessada com sucesso!!");
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    
		return connection;
	}
	
	
	public Connection conectarBDDistancia() throws ClassNotFoundException {
		Connection connection = null;  
			                
	        try {
				Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/distancia?autoReconnect=true&useSSL=false", "root", "a12762");
	            System.out.println("Base acessada com sucesso!!");
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    
		return connection;
	}

	//Função que retorna todos os hospitais cadastrados
	public String selecionarTodos() throws ClassNotFoundException, SQLException{
        
        PreparedStatement pstm = null;
		ResultSet rs = null;
		ArrayList<Hospitais> hospitais = new ArrayList<>();
		Connection conn = this.conectarBD();
        
        try{
        		pstm  = conn.prepareStatement("SELECT codigo, nome, cep, cidade, uf, leitos FROM tb_hospitais");
            rs = pstm.executeQuery();
        	
            while (rs.next()) {
                Hospitais hospAdd = new Hospitais();
                hospAdd.setCodigo(rs.getInt("codigo"));
                hospAdd.setNome(rs.getString("nome"));
                hospAdd.setCep(rs.getInt("cep"));
                hospAdd.setCidade(rs.getString("cidade"));
                hospAdd.setUf(rs.getString("uf"));
                hospAdd.setLeitos(rs.getInt("leitos"));
                hospitais.add(hospAdd);

            }
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
	        	conn.close();
            pstm.close();
          	rs.close();
        }
        return hospitais.toString();
    }
	
	
	
	public String selecionarMelhorHospital(int cep) throws ClassNotFoundException, SQLException{
		
		 PreparedStatement pstm = null;
		 ResultSet rs = null;
		 ArrayList<Hospitais> hospitais = new ArrayList<>();
		 Connection conn = this.conectarBD();
       
        try {
    			String sql = "SELECT codigo, nome, cep, cidade, uf, leitos FROM tb_hospitais where cep=? order by leitos DESC";
        		
        		pstm = conn.prepareStatement(sql);
        		pstm.setInt(1, cep);
        		rs = pstm.executeQuery();
        		
        		while (rs.next()) {
                    Hospitais hospAdd = new Hospitais();
                    hospAdd.setCodigo(rs.getInt("codigo"));
                    hospAdd.setNome(rs.getString("nome"));
                    hospAdd.setCep(rs.getInt("cep"));
                    hospAdd.setCidade(rs.getString("cidade"));
                    hospAdd.setUf(rs.getString("uf"));
                    hospAdd.setLeitos(rs.getInt("leitos"));
                    hospitais.add(hospAdd);

                }
    	        
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            } finally {
            		conn.close();
                pstm.close();
              	rs.close();
            }
            return hospitais.toString();
       
    }
	
	
//	
//	
//	public String selecionarMelhorDistancia(int cepOcorrencia) throws ClassNotFoundException, SQLException{
//		
//		 PreparedStatement pstm = null;
//		 ResultSet rs = null;
//		 ArrayList<Hospitais> hospitais = new ArrayList<>();
//		 Connection conn = this.conectarBD();
//		 
//		 PreparedStatement pstm2 = null;
//		 	ResultSet rs2 = null;
//		 	Connection conn2 = this.conectarBD();
//    		
//		 	PreparedStatement pstm3 = null;
//			 ResultSet rs3 = null;
//			 Connection conn3 = this.conectarBD();
//		
//		 		 
//		 int menorDistancia = 10000;
//      
//       try {
//    	   
//   			//String sql = "SELECT cep FROM tb_hospitais";
//    	   String sql = "SELECT cep FROM hospitaiscomleitos";
//      		
//       		
//       		pstm = conn.prepareStatement(sql);
//       	//	pstm.setInt(1, cep);
//       		rs = pstm.executeQuery();
//       	//	int contador = 0;
//       		int cepMenor=0;
//       	
//       		
//       		while (rs.next()) {
//
//       			//TODO verificar a distância com o cep da Ocorrência
//       			String sql2 = "SELECT distancia, cep FROM tb_distancias where cep=? and cepOcorrencia=?";
//
//       			
//       			pstm2 = conn2.prepareStatement(sql2);
//       			pstm2.setInt(1, rs.getInt("cep"));
//       			pstm2.setInt(2, cepOcorrencia);
//       			rs2=pstm2.executeQuery();
//
//       			while (rs2.next()) {
//       				if (rs2.getInt("distancia") < menorDistancia) {
//       					
//       				//	contador ++;
//       					menorDistancia = rs2.getInt("distancia");
//       					cepMenor = rs2.getInt("cep");
//       					System.out.println("distancia " +menorDistancia);
//       				}
//       			}
//       		}
//       		
//       	 
//       		
//   			String sql3 = "SELECT * FROM tb_hospitais where cep=?";
//   			
//   			pstm3 = conn3.prepareStatement(sql3);
//   			pstm3.setInt(1, cepMenor);
//   			rs3=pstm3.executeQuery();
//   			
//      		while (rs3.next()) {
//                   Hospitais hospAdd = new Hospitais();
//                   hospAdd.setCodigo(rs3.getInt("codigo"));
//                   hospAdd.setNome(rs3.getString("nome"));
//                   hospAdd.setCep(rs3.getInt("cep"));
//                   hospAdd.setCidade(rs3.getString("cidade"));
//                   hospAdd.setUf(rs3.getString("uf"));
//                   hospAdd.setLeitos(rs3.getInt("leitos"));
//                   hospitais.add(hospAdd);
//
//               }
//   	        
//           } catch (SQLException e) {
//               System.out.println(e.getMessage());
//           } finally {
//           		conn.close();
//               pstm.close();
//             	rs.close();
//             	conn2.close();
//                pstm2.close();
//              	rs2.close();
//              	conn3.close();
//                pstm3.close();
//              	rs3.close();
//           }
//           return hospitais.toString();
//      
//   }
//	
	
	
//	public int selecionarleitos() throws ClassNotFoundException{
//        String sql = "SELECT codigo, nome, cep, cidade, uf, leitos FROM tb_hospitais where codigo=28";
//        int numerodeLeitos = 10;
//        try (Connection conn = this.conectarBD();
//                Statement stmt  = conn.createStatement();
//                ResultSet rs    = stmt.executeQuery(sql)){
//        			     
//
//             while (rs.next()){
//				numerodeLeitos = rs.getInt("leitos");
//             };
//               
//             
//         
//           } catch (SQLException e) {
//               System.out.println(e.getMessage());
//           }
//		return numerodeLeitos;
//    }
	
	
//	public String selecionarNome() throws ClassNotFoundException{
//        String sql = "SELECT codigo, nome, cep, cidade, uf, leitos FROM tb_hospitais where codigo=28";
//        String nomedoHospital = null;
//        try (Connection conn = this.conectarBD();
//                Statement stmt  = conn.createStatement();
//                ResultSet rs    = stmt.executeQuery(sql)){
//        			     
//
//             while (rs.next()){
//				nomedoHospital = rs.getString("nome");
//             };
//               
//             
//         
//           } catch (SQLException e) {
//               System.out.println(e.getMessage());
//           }
//		return nomedoHospital;
//         
//    }
	
	
//	public void excluir(int codigo) throws ClassNotFoundException{
//        String sql = "DELETE FROM tb_hospitais WHERE codigo="+codigo;
//        
//        try (Connection conn = this.conectarBD();
//             Statement stmt  = conn.createStatement()){
//            
//            // loop through the result set
//        		stmt.executeUpdate(sql);
//	        System.out.println("Registro excluído com sucesso!!");
//	     
//            stmt.close();
//	        conn.close();
//	        
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//    }
	
	
//public void alterarNome(int codigo, String valor) throws ClassNotFoundException{
//        String sql = "UPDATE tb_hospitais SET nome = ? where codigo = ?";
//        
//        try (Connection conn = this.conectarBD();
//             PreparedStatement stmt  = conn.prepareStatement(sql)){
//        	
//        		stmt.setString(1, valor);
//        		stmt.setInt(2, codigo);
//        		stmt.executeUpdate();
//	        System.out.println("Registro alterado com sucesso!!");
//	     
//            stmt.close();
//	        conn.close();
//	        
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//    }


//	public void alterarCep(int codigo, int valor) throws ClassNotFoundException{
//		String sql = "UPDATE tb_hospitais SET cep = ? where codigo = ?";
//    
//		try (Connection conn = this.conectarBD();
//				PreparedStatement stmt  = conn.prepareStatement(sql)){
//    	
//			stmt.setInt(1, valor);
//			stmt.setInt(2, codigo);
//			stmt.executeUpdate();
//			System.out.println("Registro alterado com sucesso!!");
//     
//			stmt.close();
//			conn.close();
//        
//		} catch (SQLException e) {
//        System.out.println(e.getMessage());
//		}
//	}
	
	
//	public void alterarCidade(int codigo, String valor) throws ClassNotFoundException{
//		String sql = "UPDATE tb_hospitais SET cidade = ? where codigo = ?";
//    
//		try (Connection conn = this.conectarBD();
//				PreparedStatement stmt  = conn.prepareStatement(sql)){
//    	
//			stmt.setString(1, valor);
//			stmt.setInt(2, codigo);
//			stmt.executeUpdate();
//			System.out.println("Registro alterado com sucesso!!");
//     
//			stmt.close();
//			conn.close();
//        
//		} catch (SQLException e) {
//        System.out.println(e.getMessage());
//		}
//	}
//	
//	public void alterarUF(int codigo, String valor) throws ClassNotFoundException{
//		String sql = "UPDATE tb_hospitais SET uf = ? where codigo = ?";
//    
//		try (Connection conn = this.conectarBD();
//				PreparedStatement stmt  = conn.prepareStatement(sql)){
//    	
//			stmt.setString(1, valor);
//			stmt.setInt(2, codigo);
//			stmt.executeUpdate();
//			System.out.println("Registro alterado com sucesso!!");
//     
//			stmt.close();
//			conn.close();
//        
//		} catch (SQLException e) {
//        System.out.println(e.getMessage());
//		}
//	}
//	

//Retorna uma lista de hospitais que possuem leitos disponíveis	
	public ArrayList selecionarHospitaiscomLeitos() throws ClassNotFoundException, SQLException{
		
		 PreparedStatement pstm = null;
		 ResultSet rs = null;
		 ArrayList<Hospitais> hospitais = new ArrayList<>();
		 Connection conn = this.conectarBD();
		 
		 try {
   	   
			 	String sql = "SELECT codigo, nome,cep,cidade,uf,leitos FROM tb_hospitais where leitos > 0";
     		 		
      			pstm = conn.prepareStatement(sql);
      			rs = pstm.executeQuery();
    
      			while (rs.next()) {
      			
      				 Hospitais hospAdd = new Hospitais();
      				 hospAdd.setCodigo(rs.getInt("codigo"));
	                 hospAdd.setNome(rs.getString("nome"));
	                 hospAdd.setCep(rs.getInt("cep"));
	                 hospAdd.setCidade(rs.getString("cidade"));
	                 hospAdd.setUf(rs.getString("uf"));
	                 hospAdd.setLeitos(rs.getInt("leitos"));
	                 hospitais.add(hospAdd);

      			}
  	        
         } catch (SQLException e) {
              System.out.println(e.getMessage());
         } finally {
          	conn.close();
            pstm.close();
            	rs.close();
         }
	  		
	  return hospitais;
     
  }
	

}
