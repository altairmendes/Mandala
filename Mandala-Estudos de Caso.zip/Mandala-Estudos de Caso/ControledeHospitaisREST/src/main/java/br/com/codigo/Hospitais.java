package br.com.codigo;

public class Hospitais {
	int codigo, cep, leitos;
	String nome, cidade, uf;
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCep() {
		return cep;
	}
	public void setCep(int cep) {
		this.cep = cep;
	}
	public int getLeitos() {
		return leitos;
	}
	public void setLeitos(int leitos) {
		this.leitos = leitos;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}

	@Override
    public String toString() {
		
		
	//	return "{\"Hospital\":\"Nome\":\"" + nome + "\",\"Cep\":\"" + cep + "\", \"Cidade\":\"" + cidade + "\", \"UF\":\"" + uf + "\", \"Leitos\":\""
	//				               + leitos + "\"}";
		
		
		return "{\"Nome\":\"" + nome + "\",\"Cep\":\"" + cep + "\", \"Cidade\":\"" + cidade + "\", \"UF\":\"" + uf + "\", \"Leitos\":\""
			               + leitos + "\"}";
      //  return "\n{\t\"Nome\":\"" + nome + "\", \n\t\"Cep\":\"" + cep + "\", \n\t\"Cidade\":\"" + cidade + "\", \n\t\"UF\":\"" + uf + "\", \n\t\"Leitos\":\""
       //         + leitos + "\"\n}\n";
      
    }
}
