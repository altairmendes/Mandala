package br.com.ABM.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAO {
	
	
//Conectar ao Banco	
	public Connection conectarBD() throws ClassNotFoundException {
		Connection connection = null;  
			                
	        try {
				Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ambulancias?autoReconnect=true&useSSL=false", "root", "a12762");
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    
		return connection;
	}
	
//Criar tabela chamados	
	public void criarTabelaChamados() {
		
		String sql = "CREATE TABLE tb_chamados\n" 
				+"(\n" 
				+"	codigo INTEGER	auto_increment primary key,\n" 
				+"    numeroChamado INTEGER not null,\n" 
				+"    descricao VARCHAR(50) not null,\n" 
				+	"    cep   INTEGER	NOT NULL,\n" 
				+	"    cidade   VARCHAR(50)	NOT NULL,\n" 
				+	"    uf   VARCHAR(2)	NOT NULL\n" 	
			+	");";

		  
		try (Connection conn = this.conectarBD();
    			Statement pstmt = conn.createStatement()) {
	        
			pstmt.executeUpdate(sql);
	        System.out.println("Tabela criada com sucesso!!");
	        pstmt.close();
	        conn.close();
	        
	     } 
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
		
	}

//Criar tabela Hospitais
	public void criarTabelaHospitais() {
		
		String sql = "CREATE TABLE tb_hospitais\n" 
				+"(\n" 
				+"	codigo INTEGER	auto_increment primary key,\n" 
				+"    nome VARCHAR(50) not null,\n" 
				+	"    cep   INTEGER	NOT NULL\n" 
			+	");";

		  
		try (Connection conn = this.conectarBD();
    			Statement pstmt = conn.createStatement()) {
	        
			pstmt.executeUpdate(sql);
	        pstmt.close();
	        conn.close();
	        
	     } 
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
		
	}

//Ciação da tabela que associa o hospital de destino ao local de origem do chamado.
	public void criarTabelaCepChamadoCepHospitais() {
		
		String sql = "CREATE TABLE tb_CepChamadosCepHospitais\n" 
				+"(\n" 
				+"	codigo INTEGER	auto_increment primary key,\n" 
				+"    cepChamado INTEGER not null,\n" 
				+	"    cepHospital   INTEGER	NOT NULL\n" 
			+	");";

		  
		try (Connection conn = this.conectarBD();
    			Statement pstmt = conn.createStatement()) {
	        
			pstmt.executeUpdate(sql);
	        pstmt.close();
	        conn.close();
	        
	     } 
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
		
	}


//Função que realiza o cadasto dos chamados
	public void cadastrarChamado(String descricao, Integer cep, String cidade, String uf) throws ClassNotFoundException {
        String sql = "INSERT INTO tb_chamados (descricao, cep, cidade, uf) VALUES(?,?,?,?)";
 
        try (Connection conn = this.conectarBD();
        			PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
        		pstmt.setString(1,descricao);
        		pstmt.setInt(2, cep);
        		pstmt.setString(3, cidade);
        		pstmt.setString(4, uf);

        		pstmt.executeUpdate();
    	        System.out.println("Dados inseridos com sucesso!!");

    	        pstmt.close();
    	        conn.close();
    	        
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
	
//Função que realiza o cadasto dos chamados pelo cep
		public void cadastrarChamado(Integer cep) throws ClassNotFoundException {
	        String sql = "INSERT INTO tb_chamados (cep) VALUES(?)";
	 
	        try (Connection conn = this.conectarBD();
	        			PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            
	        		pstmt.setInt(1, cep);
	     
	        		pstmt.executeUpdate();
	    	        System.out.println("Dados inseridos com sucesso!!");

	    	        pstmt.close();
	    	        conn.close();
	    	        
	        
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    }
		
	
//Função que associa, de fato, um CEP da origem dos chamados ao CEP do hospital que deve ser enviada a ambulância
	public void cadastrarCepChamadosCepHospitais( Integer cepChamado, Integer cepHospital) throws ClassNotFoundException {
		String sql = "INSERT INTO tb_CepChamadosCepHospitais (cepChamado, cepHospital) VALUES(?,?)";

		try (Connection conn = this.conectarBD();
    			PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
    			pstmt.setInt(1, cepChamado);
    			pstmt.setInt(2, cepHospital);
    	
    			pstmt.executeUpdate();
    			System.out.println("Dados inseridos com sucesso!!");

    			pstmt.close();
    			conn.close();
	        
    
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

//Função que realiza o cadastro dos hospitais. Essa função associa o cep ao nome do hospital.
	public void cadastrarHospitais( String nome, Integer cep) throws ClassNotFoundException {
		String sql = "INSERT INTO tb_hospitais (nome, cep) VALUES(?,?)";

		try (Connection conn = this.conectarBD();
    			PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
    			pstmt.setString(1, nome);
    			pstmt.setInt(2, cep);
    	
    			pstmt.executeUpdate();
	        System.out.println("Dados inseridos com sucesso!!");

	        pstmt.close();
	        conn.close();
	        
    
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}


//Função que informa todos os chamados realizados
	public void selecionarTodosOsChamados() throws ClassNotFoundException{
        String sql = "SELECT codigo, numeroChamado, descricao, cep, cidade, uf FROM tb_chamados";
        
        try (Connection conn = this.conectarBD();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)){
        	
        			System.out.println("codigo" + "      "+ "\t" +
            				"numeroChamado" + "                     "+ "\t" +
    				"descrição" + "                     "+ "\t" +
        			"cep" + "                "+ "\t" +
                "cidade" + "             "+ "\t" +
                "uf");
            
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("codigo") + "    "+ "\t" + 
                        				rs.getInt("numeroChamado") + "                  "+ "\t" +
                        				rs.getString("descricao") + "          "+ "\t" +
                                   rs.getInt("cep") + "           "+ "\t" +
                                   rs.getString("cidade") + "         "+ "\t" +
                                   rs.getString("uf"));
            }
            rs.close();
            stmt.close();
	        conn.close();
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

//Função que realiza a exclusão do chamado	
	public void excluirChamado(int codigo) throws ClassNotFoundException{
        String sql = "DELETE FROM tb_chamados WHERE codigo="+codigo;
        
        try (Connection conn = this.conectarBD();
             Statement stmt  = conn.createStatement()){
            
            // loop through the result set
        		stmt.executeUpdate(sql);
	        System.out.println("Registro excluído com sucesso!!");
	     
            stmt.close();
	        conn.close();
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
	
//Função que retorna o cep do hospital que a ambulância deve seguir após atender 
	//a um chamado. De acordo com o cep de origem, a função retorna o cep de destino.
	//Sempre é com base em um cep já cadastrado, não importando a distância ou leitos disponíveis.
	public int selecionarCepHospital(int cepChamado) throws ClassNotFoundException{
		String sql = "SELECT cepHospital FROM tb_CepChamadosCepHospitais WHERE cepChamado =" + cepChamado;
        		try (Connection conn = this.conectarBD();
                Statement stmt  = conn.createStatement();
                ResultSet rs    = stmt.executeQuery(sql)){
        		 
        			while (rs.next()) {
                    return rs.getInt("cepHospital");
                 }
        			rs.close();
        			stmt.close();
        			conn.close();
     	     
        			return 0;
	        
        		} catch (SQLException e) {
        			System.out.println(e.getMessage());
        		}
        		return 0;
    }
	
//Função que retorna o identificador do último chamado incluído	
	public int selecionarIDUltimoChamado() throws ClassNotFoundException{
		String sql = "SELECT max(codigo) FROM tb_chamados";
        		try (Connection conn = this.conectarBD();
                Statement stmt  = conn.createStatement();
                ResultSet rs    = stmt.executeQuery(sql)){
        		 
        			while (rs.next()) {
                    return rs.getInt("max(codigo)");
                 }
        			rs.close();
        			stmt.close();
        			conn.close();
     	     
        			return 0;
	        
        		} catch (SQLException e) {
        			System.out.println(e.getMessage());
        		}
        		return 0;
    }	
	

//Função que retorna o nome do hospital de destino da ambulância.	
	public String selecionarNomeHospital(int cepHospital) throws ClassNotFoundException{
		String sql = "SELECT nome from tb_Hospitais where cep =" +cepHospital;
    
		try (Connection conn = this.conectarBD();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql)){
    		//stmt.executeUpdate();
    		 
    			while (rs.next()) {
                return rs.getString("nome");
             }
    			rs.close();
    			stmt.close();
    			conn.close();
 	     
    			return "Erro";
 	 
        } catch (SQLException e) {
        		System.out.println(e.getMessage());
        }
		return "Erro";
	}

	
//Função que altera o cep de destino de uma ambulância com base no cep de origem do chamado.	
	public void alterarCepAssociados(int cepHospital, int cepChamado) throws ClassNotFoundException{
		String sql = "UPDATE tb_CepChamadosCepHospitais SET cep = ? where codigo = ?";
    
		try (Connection conn = this.conectarBD();
				PreparedStatement stmt  = conn.prepareStatement(sql)){
    	
			stmt.setInt(1, cepHospital);
			stmt.setInt(2, cepChamado);
			stmt.executeUpdate();
			System.out.println("Registro alterado com sucesso!!");
     
			stmt.close();
			conn.close();
        
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
		
}
