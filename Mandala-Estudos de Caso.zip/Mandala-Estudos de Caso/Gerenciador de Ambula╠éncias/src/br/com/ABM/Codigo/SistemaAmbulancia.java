package br.com.ABM.Codigo;

import java.util.Scanner;

import br.com.ABM.DAO.*;

public class SistemaAmbulancia {
	
	public static void main(String[] args) throws ClassNotFoundException {
		DAO banco = new DAO();
	    Scanner sc = new Scanner(System.in);
		int opcao = 0;
		
		do {
			System.out.println("====================================");
			System.out.println("## Sistema de Gerenciamento de Rotas de Ambulância ##");
			System.out.println("## Escolha uma das opções abaixo ##");
		    System.out.println("Opção 1 - Cadastrar chamados");
		    System.out.println("Opção 2 - Associar cep dos chamados ao cep dos hospitais");
		    System.out.println("Opção 3 - Cadastrar hospitais");
		    System.out.println("Opção 4 - Listar chamados");
		    System.out.println("Opção 5 - Excluir chamados");

		    System.out.println("Opção 0 - Sair do programa");
		    System.out.println("_______________________");
		           
		    System.out.print("Digite aqui sua opção: ");
		    opcao = Integer.parseInt(sc.nextLine());
		    
		    switch (opcao) {
		   
		    case 1:       
		             
		            System.out.print("Digite a descrição do chamado: ");
		            String valorDescricao = sc.nextLine();
		            
		            System.out.print("Digite o cep: ");
		            Integer valorCep = Integer.parseInt(sc.nextLine());
		             
		            System.out.print("Digite a cidade: ");
		            String valorCidade = sc.nextLine();
		             
		            System.out.print("Digite a UF: ");
		            String valorUF = sc.nextLine();
		            
		            System.out.println();
		            int cepHospitalAtendimento = banco.selecionarCepHospital(valorCep);
	    				String nomeHospitalAtendimento = banco.selecionarNomeHospital(cepHospitalAtendimento);
		    			banco.cadastrarChamado(valorDescricao, valorCep, valorCidade, valorUF);
			        int idUltimoChamado = banco.selecionarIDUltimoChamado();

		    			
		    			System.out.println("O identificador do chamado é: " +idUltimoChamado+ " e o hospital que a ambulância deve levar o paciente é: " + nomeHospitalAtendimento);
		    			
		    			break;

		    case 2:
		    			System.out.print("Digite o número do cep origem: ");
		    			Integer valorCepOrigem = Integer.parseInt(sc.nextLine());
	             
		    			System.out.print("Digite o número do cep destino: ");
		    			Integer valorCepDestino = Integer.parseInt(sc.nextLine());
		    		    
		    			System.out.println();
		    			banco.cadastrarCepChamadosCepHospitais(valorCepOrigem, valorCepDestino);
		    			break;
		    case 3:
		    			System.out.print("Digite o nome do hospital: ");
		    			String valorNomeHospital = sc.nextLine();
		    			
		    			System.out.print("Digite o nome do cep: ");
		    			Integer valorCepHospital = Integer.parseInt(sc.nextLine());
		    			
		    			banco.cadastrarHospitais(valorNomeHospital, valorCepHospital);
		    			break;
		    case 4:
		    			banco.selecionarTodosOsChamados();
		    			break;
		    case 5:
    					System.out.print("Digite o identificador do chamado a ser excluído: ");
    					Integer idExcluido = Integer.parseInt(sc.nextLine());
    					banco.excluirChamado(idExcluido);
    					break;
		   
		    case 0:
		    			System.exit(0);
		    	
		    	default:
		    		System.out.println("Opção inválida!");
		    }

	    		
	    }while(opcao!=0);
	    
		

	}

}
