package br.com.abm;

import br.com.dao.*;
//import br.com.codigo.*;

//import com.google.gson.Gson; 


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.List;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.uri.UriComponent.Type;
import com.sun.jersey.server.impl.model.HttpHelper;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//Caminho principal -- http://localhost:8080/AMBFINAL/rest/ambulancia//chamado/cadastrar/{cepOrigem}
@Path("/ambulancia")
public class AMBFINAL {

//Chamada a 	um método de teste do REST
	@GET
	@Produces("text/html")
	public Response PaginaTeste()
	{
		String saidaTeste = "<h1>Sistema de Gerenciamento de Ambulancias<h1>" +
				"<p>Servico Rest... OK <br>Ping @ " + new Date().toString() + "</p<br>";
		return Response.status(200).entity(saidaTeste).build();
	}
	
	
	//Caminho principal -- http://localhost:8080/AMBFINAL/rest/ambulancia/chamado/cadastrar/{cepOrigem}
	@PUT
    @Path("/chamado/cadastrar/{cepOrigem}")
    @Produces(MediaType.APPLICATION_JSON)
    public String CadastrarChamado(@PathParam("cepOrigem") int cepOrigem) throws ClassNotFoundException, SQLException, IOException, JSONException{
     
		DAO banco = new DAO();
		banco.cadastrarChamado(cepOrigem);
		Integer ultimoID = banco.selecionarIDUltimoChamado();
		String resposta = null;
		
		resposta = IOUtils.toString(new URL("http://localhost:8080/AMBFINAL/rest/ambulancia/hospital/distancia/"+ cepOrigem).openStream(), Charset.forName("UTF-8").toString());
		
      
        
         return "{"+resposta + "\n\t\"Chamado\": \"" + ultimoID + "\"\n}".toString();
        
        
	}
	
	
	
	
	//Caminho principal -- http://localhost:8080/AMBFINAL/rest/ambulancia/hospital/distancia/{cepOrigem}
	//Retorna o nome, a distância e o cep do hospital mais próximo da origem que possui leitos disponíveis	
	@GET
    @Path("/hospital/distancia/{cepOrigem}")
    @Produces(MediaType.APPLICATION_JSON)
    public String listarCepHospitalDistancia(@PathParam("cepOrigem") int cepOrigem) throws ClassNotFoundException, SQLException, IOException, JSONException{
     
       ArrayList<Integer> listaCeps = new ArrayList<Integer>();
       JSONArray json = new JSONArray(IOUtils.toString(new URL("http://localhost:8080/ControledeHospitaisREST/rest/hospitais/listar/comleitos").openStream(), Charset.forName("UTF-8").toString()));
         for (int i=0; i<json.length();i++) {
        	 	JSONObject endereco = json.getJSONObject(i);
        	 	Integer cep = endereco.getInt("Cep");
        	 	listaCeps.add(cep);
         }
         
        
         return calculaMelhorDistancia(cepOrigem,listaCeps);
        
        
	}
	
	
	//Retorna o nome, o cep e a distância do hospital mais perto da origem do chamado
	//que possui leitos disponíveis. Há cep de hospitais em uma lista de hospitais que possuem
		//leitos disponíveis que devem ser comparados.
		public String calculaMelhorDistancia (int cepOrigem, List cep) throws ClassNotFoundException, SQLException, IOException, JSONException {
			int i=0, cepMelhor=0;
			float distancia = 0, menor = 100000000;
			for (i=0; i < cep.size(); i++) {
				
				
				distancia = selecionarDistancia(cepOrigem, (int)cep.get(i));
				
				if (distancia < menor) {

					menor = distancia;
					cepMelhor = (int) cep.get(i);

				}
				
			}
			
			String nomeHospital = new DAO().selecionarNomeHospital(cepMelhor);
			
			return "{\n\t\"Nome\": \""+ nomeHospital + "\",\n\t\"Distância\": \""+ menor + "\",\n\t\"Cep\": \"" + cepMelhor + "\"\n}".toString();

		}
		
		//Retorna a distância entre dois ceps
		//@GET
	    //@Path("/hospital/distancia/{cepOrigem}/{cepDestino}")
	    //@Produces(MediaType.APPLICATION_JSON)
	    public Float selecionarDistancia(int cepOrigem,int cepDestino) throws ClassNotFoundException, SQLException, IOException, JSONException{
	     
	      
	       JSONObject json = new JSONObject(IOUtils.toString(new URL("http://192.168.0.108/api/consulta.php/consulta/"+cepOrigem+"/"+cepDestino+"/").openStream(), Charset.forName("UTF-8").toString()));
	         Float distancia = (float) json.getInt("distancia");
	         return distancia;
	                
		}
		
	
}
