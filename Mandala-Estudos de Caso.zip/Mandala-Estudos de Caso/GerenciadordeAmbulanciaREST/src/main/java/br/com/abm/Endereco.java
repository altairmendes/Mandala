package br.com.abm;

public class Endereco {

		 
	    private String  Nome, Cidade, UF;
	    private Integer Cep, leitos;
	    
	 
	  

		public String getNome() {
			return Nome;
		}




		public void setNome(String nome) {
			Nome = nome;
		}




		public String getCidade() {
			return Cidade;
		}




		public void setCidade(String cidade) {
			Cidade = cidade;
		}




		public String getUF() {
			return UF;
		}




		public void setUF(String uF) {
			UF = uF;
		}




		public Integer getCep() {
			return Cep;
		}




		public void setCep(Integer cep) {
			Cep = cep;
		}




		public Integer getLeitos() {
			return leitos;
		}




		public void setLeitos(Integer leitos) {
			this.leitos = leitos;
		}




		@Override
	    public String toString() {
			return "{\"Nome\":\"" + Nome + "\", \"Cep\":\"" + Cep + "\", \"Cidade\":\"" + Cidade + "\", \"UF\":\"" + UF + "\", \"Leitos\":\""
	                + leitos + "\"}";
	    }
	 
	
}
