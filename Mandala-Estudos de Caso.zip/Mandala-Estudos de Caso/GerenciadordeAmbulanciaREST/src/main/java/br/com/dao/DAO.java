package br.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class DAO {
	
	
//Função que realiza a conexão com o Banco de Dados	
	public Connection conectarBD() throws ClassNotFoundException {
		Connection connection = null;  
			                
	        try {
				Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ambulancias?autoReconnect=true&useSSL=false", "root", "a12762");
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    
		return connection;
	}
	
		
//Função que realiza o cadasto dos chamados pelo cep
	public void cadastrarChamado(Integer cep) throws ClassNotFoundException {
		   String sql = "INSERT INTO tb_chamados (cep) VALUES(?)";
		 
		   try (Connection conn = this.conectarBD();
		        			PreparedStatement pstmt = conn.prepareStatement(sql)) {
		            
			   pstmt.setInt(1, cep);
		     
		       pstmt.executeUpdate();
		    	   System.out.println("Dados inseridos com sucesso!!");

		    	   pstmt.close();
		    	   conn.close();
		    	        
		        
		   } catch (SQLException e) {
		            System.out.println(e.getMessage());
		   }
	}
	
	
//Função que retorna o identificador do último chamado incluído	
	public int selecionarIDUltimoChamado() throws ClassNotFoundException{
			String sql = "SELECT max(codigo) FROM tb_chamados";
		try (Connection conn = this.conectarBD();
	           Statement stmt  = conn.createStatement();
	           ResultSet rs    = stmt.executeQuery(sql)){
	        		 
	        		while (rs.next()) {
	                 return rs.getInt("max(codigo)");
	            }
	        		rs.close();
	        		stmt.close();
	        		conn.close();
	     	     
	        		return 0;
		        
	     } catch (SQLException e) {
	        		System.out.println(e.getMessage());
	       }
	       return 0;
	}	
			
//Função que retorna o nome do hospital, com base em um CEP informado.
	public String selecionarNomeHospital(int cepHospital) throws ClassNotFoundException{
    String sql = "SELECT nome from tb_Hospitais where cep =" +cepHospital;
    
    try (Connection conn = this.conectarBD();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql)){
    		 
    		while (rs.next()) {
                return rs.getString("nome");
             }
         rs.close();
         stmt.close();
 	     conn.close();
 	     
 	     return "Erro";
 	 
        
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
	return "Erro";
}

//Retorna o nome, o cep e a distância do hospital mais perto da origem do chamado
//que possui leitos disponíveis. Há cep de hospitais em uma lista de hospitais que possuem
	//leitos disponíveis que devem ser comparados.
//	public String calculaMelhorDistancia (int cepOrigem, List cep) throws ClassNotFoundException, SQLException {
//		int i=0, cepMelhor=0;
//		float distancia = 0, menor = 100000000;
//		for (i=0; i < cep.size(); i++) {
//			
//			
//			distancia = selecionarDistancia(cepOrigem, (int)cep.get(i));
//			
//			if (distancia < menor) {
//
//				menor = distancia;
//				cepMelhor = (int) cep.get(i);
//
//			}
//			
//		}
//		
//		String nomeHospital = selecionarNomeHospital(cepMelhor);
//		
//		return "{\n\t\"Nome\": \""+ nomeHospital + "\",\n\t\"Distância\": \""+ menor + "\",\n\t\"Cep\": \"" + cepMelhor + "\"\n}".toString();
//
//	}
//	
	
	
//Função que devolve a distância entre dois CEP. Neste caso, devolve a distância
	//entre o CEP da origem do chamado e o do hospital.
//	public Float selecionarDistancia(int cepOrigem, int cepHospital) throws ClassNotFoundException, SQLException{
//		
//		Float distancia = (float) 0.0;
//		PreparedStatement pstm = null;
//		 ResultSet rs = null;
//		 Connection conn = this.conectarBD();
//	
//	      try {
//	    		String sql = "SELECT distancia FROM tb_distancias WHERE cepOrigem = ? and cepDestino=?";
//	    		pstm = conn.prepareStatement(sql);
//	   		pstm.setInt(1, cepOrigem);
//	   		pstm.setInt(2, cepHospital);
//	   		
//	    		rs = pstm.executeQuery();
//
//	      		while (rs.next()) {
//	      			distancia = rs.getFloat("distancia");
//	      		}
//	      }catch (SQLException e) {
//	                System.out.println(e.getMessage());
//	            } finally {
//	            		conn.close();
//	                pstm.close();
//	              	rs.close();
//	            }
//		return distancia;
//	   	 
//	  }
			
}
