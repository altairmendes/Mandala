package br.com.ABM.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAO {
	
//Função que realiza a conexão com o Banco de Dados Hospitais
	public Connection conectarBD() throws ClassNotFoundException {
		Connection connection = null;  
			                
	        try {
				Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitais?autoReconnect=true&useSSL=false", "root", "a12762");
	            System.out.println("Base acessada com sucesso!!");
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    
		return connection;
	}
	
//Função que cria a tabela de hospitais	
	public void criarTabela() {
		
		String sql = "CREATE TABLE tb_hospitais\n" 
				+"(\n" 
				+"	codigo INTEGER	auto_increment primary key,\n" 
				+"    nome VARCHAR(100) not null,\n" 
				+	"    cep   INTEGER	NOT NULL,\n" 
				+	"    cidade   VARCHAR(50)	NOT NULL,\n" 
				+	"    leitos   INTEGER(3)	NOT NULL,\n" 
				+	"    uf   VARCHAR(2)	NOT NULL\n" 	
			+	");";

		  
		try (Connection conn = this.conectarBD();
    			Statement pstmt = conn.createStatement()) {
	        
			pstmt.executeUpdate(sql);
	        System.out.println("Tabela criada com sucesso!!");
	        pstmt.close();
	        conn.close();
	        
	     } 
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
		
	}
	
//Função que insere os dados na tabela de hospitais	
	public void inserirDados(String nome, Integer cep, String cidade, String uf, Integer leitos) throws ClassNotFoundException {
        String sql = "INSERT INTO tb_hospitais (nome, cep, cidade, uf, leitos) VALUES(?,?,?,?,?)";
 
        try (Connection conn = this.conectarBD();
        			PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
        		pstmt.setString(1, nome);
        		pstmt.setInt(2,cep);
        		pstmt.setString(3, cidade);
        		pstmt.setString(4, uf);
        		pstmt.setInt(5, leitos);

        		pstmt.executeUpdate();
    	        System.out.println("Dados inseridos com sucesso!!");

    	        pstmt.close();
    	        conn.close();
    	        
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
	
//Função que informa os dados de todos os hospitais cadastrados	
	public void selecionarTodos() throws ClassNotFoundException{
        String sql = "SELECT codigo, nome, cep, cidade, uf, leitos FROM tb_hospitais";
        
        try (Connection conn = this.conectarBD();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)){
        	
        			System.out.println("codigo" + "      "+ "\t" +
    				"nome" + "                     "+ "\t" +
    				"leitos" + "      "+ "\t" +
        			"cep" + "                "+ "\t" +
                "cidade" + "             "+ "\t" +
                "uf");
            
            while (rs.next()) {
                System.out.println(rs.getInt("codigo") + "    "+ "\t" + 
                        				rs.getString("nome") + "                  "+ "\t" +
                        				rs.getInt("leitos") + "          "+ "\t" +
                                   rs.getInt("cep") + "           "+ "\t" +
                                   rs.getString("cidade") + "         "+ "\t" +
                                   rs.getString("uf"));
            }
            rs.close();
            stmt.close();
	        conn.close();
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
	
//Função que exclui algum hospital da lista de cadastrados	
	public void excluir(int codigo) throws ClassNotFoundException{
        String sql = "DELETE FROM tb_hospitais WHERE codigo="+codigo;
        
        try (Connection conn = this.conectarBD();
             Statement stmt  = conn.createStatement()){
            
        		stmt.executeUpdate(sql);
	        System.out.println("Registro excluído com sucesso!!");
	     
            stmt.close();
	        conn.close();
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
	
//Função que altera o nome do hospital cadastrado	
public void alterarNome(int codigo, String valor) throws ClassNotFoundException{
        String sql = "UPDATE tb_hospitais SET nome = ? where codigo = ?";
        
        try (Connection conn = this.conectarBD();
             PreparedStatement stmt  = conn.prepareStatement(sql)){
        	
        		stmt.setString(1, valor);
        		stmt.setInt(2, codigo);
        		stmt.executeUpdate();
	        System.out.println("Registro alterado com sucesso!!");
	     
            stmt.close();
	        conn.close();
	        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

//Função que altera o CEP do hospital cadastrado
	public void alterarCep(int codigo, int valor) throws ClassNotFoundException{
		String sql = "UPDATE tb_hospitais SET cep = ? where codigo = ?";
    
		try (Connection conn = this.conectarBD();
				PreparedStatement stmt  = conn.prepareStatement(sql)){
    	
			stmt.setInt(1, valor);
			stmt.setInt(2, codigo);
			stmt.executeUpdate();
			System.out.println("Registro alterado com sucesso!!");
     
			stmt.close();
			conn.close();
        
		} catch (SQLException e) {
        System.out.println(e.getMessage());
		}
	}
	
//Função que altera a cidade do hospital cadastrado	
	public void alterarCidade(int codigo, String valor) throws ClassNotFoundException{
		String sql = "UPDATE tb_hospitais SET cidade = ? where codigo = ?";
    
		try (Connection conn = this.conectarBD();
				PreparedStatement stmt  = conn.prepareStatement(sql)){
    	
			stmt.setString(1, valor);
			stmt.setInt(2, codigo);
			stmt.executeUpdate();
			System.out.println("Registro alterado com sucesso!!");
     
			stmt.close();
			conn.close();
        
		} catch (SQLException e) {
        System.out.println(e.getMessage());
		}
	}

//Função que altera a UF do hospital cadastrado
	public void alterarUF(int codigo, String valor) throws ClassNotFoundException{
		String sql = "UPDATE tb_hospitais SET uf = ? where codigo = ?";
    
		try (Connection conn = this.conectarBD();
				PreparedStatement stmt  = conn.prepareStatement(sql)){
    	
			stmt.setString(1, valor);
			stmt.setInt(2, codigo);
			stmt.executeUpdate();
			System.out.println("Registro alterado com sucesso!!");
     
			stmt.close();
			conn.close();
        
		} catch (SQLException e) {
        System.out.println(e.getMessage());
		}
	}
	
}
