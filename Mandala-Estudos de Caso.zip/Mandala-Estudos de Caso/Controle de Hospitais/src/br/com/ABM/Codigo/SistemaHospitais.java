package br.com.ABM.Codigo;

import java.util.Scanner;

import br.com.ABM.DAO.*;

public class SistemaHospitais {
	
	public static void main(String[] args) throws ClassNotFoundException {
		DAO banco = new DAO();
	    Scanner sc = new Scanner(System.in);
		int opcao, opcao2 = 0;
		
		do {
			System.out.println("====================================");
			System.out.println("## Sistema de Controle dos Hospitais ##");
			System.out.println("## Escolha uma das opções abaixo ##");
		    System.out.println("Opção 1 - Cadastrar hospitais");
		    System.out.println("Opção 2 - Alterar dados");
		    System.out.println("Opção 3 - Excluir dados");
		    System.out.println("Opção 4 - Listar hospitais cadastrados");
		    System.out.println("Opção 0 - Sair do programa");
		    System.out.println("_______________________");
		           
		    System.out.print("Digite aqui sua opção: ");
		    opcao = Integer.parseInt(sc.nextLine());
		    
		    switch (opcao) {
		  
		    case 1:       
		            System.out.print("Digite o nome: ");
		            String valorNome = sc.nextLine();
		             
		            System.out.print("Digite o cep: ");
		            Integer valorCep = Integer.parseInt(sc.nextLine());
		            
		            System.out.print("Digite a cidade: ");
		            String valorCidade = sc.nextLine();
		             
		            System.out.print("Digite a UF: ");
		            String valorUF = sc.nextLine();
		             
		            System.out.print("Digite a quantidade de leitos disponíveis: ");
		            Integer valorLeitos = Integer.parseInt(sc.nextLine());
		            
		            System.out.println();
		    			banco.inserirDados(valorNome,valorCep, valorCidade, valorUF, valorLeitos);
		    			break;

		    case 2:
		    			System.out.print("Digite o identificador do registro a ser alterado: ");
		    			Integer idAlterado = Integer.parseInt(sc.nextLine());
		    			
		    			System.out.print("Digite o campo do registro a ser alterado:\n ");
		    		    System.out.println("Opção 1 - Nome");
		    		    System.out.println("Opção 2 - CEP");
		    		    System.out.println("Opção 3 - Cidade");
		    		    System.out.println("Opção 4 - UF");
		    		    System.out.println("Opção 0 - Cancelar");
		    		    System.out.println("_______________________");
		    		    
		    		    opcao2 = Integer.parseInt(sc.nextLine());
		    		    
		    		    switch (opcao2) {
		    		   
		    		    case 1:       
		    		            System.out.print("Digite o novo nome: ");
		    		            String valorNome2 = sc.nextLine();
		    		            banco.alterarNome(idAlterado,valorNome2);
		    		            break;
		    			case 2:
		    		            System.out.print("Digite o novo cep: ");
		    		            Integer valorCep2 = Integer.parseInt(sc.nextLine());
		    		            banco.alterarCep(idAlterado,valorCep2);

		    		            break;
		    			case 3:
		    		            System.out.print("Digite a nova cidade: ");
		    		            String valorCidade2 = sc.nextLine();
		    		            banco.alterarCidade(idAlterado,valorCidade2);

		    		            break;
		    			case 4:        
		    		            System.out.print("Digite a nova UF: ");
		    		            String valorUF2 = sc.nextLine();
		    		            banco.alterarUF(idAlterado,valorUF2);

		    			case 0:
		    					break;
		    				
		    			default:
				    		System.out.println("Opção inválida! Voltando ao menu principal!");
				    		break;

		    		    }
		    			break;
		    case 3:
		    			System.out.print("Digite o identificador do registro a ser excluído: ");
		    			Integer idExcluido = Integer.parseInt(sc.nextLine());
		    			banco.excluir(idExcluido);
		    			break;
		    case 4:
		    			banco.selecionarTodos();
		    			break;
		    case 0:
		    			System.exit(0);
		    	
		    	default:
		    		System.out.println("Opção inválida!");
		    }

	    		
	    }while(opcao!=0);
	    
		
		
	}

}
